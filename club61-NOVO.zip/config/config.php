<?php
// Configuração Supabase — Club61
define('SUPABASE_URL',         'https://eezvwckzglsqlsomabvo.supabase.co');
define('SUPABASE_ANON_KEY',    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVlenZ3Y2t6Z2xzcWxzb21hYnZvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM2MTM3ODgsImV4cCI6MjA4OTE4OTc4OH0.qzXT4aVYFuLO5MW9Smdmgk4S-dLaYp0iNiyFSv9Q2x8');
define('SUPABASE_SERVICE_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVlenZ3Y2t6Z2xzcWxzb21hYnZvIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MzYxMzc4OCwiZXhwIjoyMDg5MTg5Nzg4fQ.MHUrJwrY8w28iM1AgckIATJ3ubdUC9N6AzsgZEGAEzI');

// Cidades do chat
define('CHAT_CITIES', ['Presidente Prudente', 'Maringá', 'Londrina']);

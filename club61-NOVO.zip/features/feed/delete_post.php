<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: /features/feed/index.php'); exit; }

$uid    = c61_uid();
$postId = (int)($_POST['post_id'] ?? 0);
if ($postId > 0) {
    sb_delete('/rest/v1/posts?id=eq.' . $postId . '&user_id=eq.' . urlencode($uid));
}
header('Location: /features/feed/index.php?status=ok&message=' . urlencode('Post excluído.'));
exit;

<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();

$pageTitle  = 'Chat';
$activePage = 'chat';
$uid        = c61_uid();

// Cidade selecionada
$selectedCity = trim($_GET['city'] ?? CHAT_CITIES[0]);
if (!in_array($selectedCity, CHAT_CITIES, true)) {
    $selectedCity = CHAT_CITIES[0];
}

// Enviar mensagem
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = trim($_POST['content'] ?? '');
    $city    = trim($_POST['city']    ?? $selectedCity);
    if ($content !== '' && mb_strlen($content, 'UTF-8') <= 500) {
        sb_post('/rest/v1/general_messages', [
            'user_id' => $uid,
            'content' => $content,
            'city'    => $city,
        ]);
    }
    header('Location: /features/chat/index.php?city=' . urlencode($city));
    exit;
}

// Buscar mensagens da cidade
$messages = sb_get('/rest/v1/general_messages?city=eq.' . rawurlencode($selectedCity) . '&select=id,user_id,content,created_at&order=created_at.asc&limit=80');

// Buscar perfis dos autores
$authorMap = [];
$authorIds = array_unique(array_filter(array_column($messages, 'user_id')));
if (!empty($authorIds)) {
    $authors = sb_get('/rest/v1/profiles?select=id,display_id,username,avatar_url,last_seen&id=in.(' . implode(',', $authorIds) . ')');
    foreach ($authors as $a) { if (isset($a['id'])) $authorMap[$a['id']] = $a; }
}

// Membros na cidade
$cityMembers = sb_get('/rest/v1/profiles?cidade=eq.' . rawurlencode($selectedCity) . '&select=id,display_id,username,avatar_url,last_seen&order=last_seen.desc&limit=50');

require ROOT . '/config/layout_top.php';
?>

<style>
.chat-layout{display:flex;height:calc(100vh - 0px);overflow:hidden}

/* Painel esquerdo — cidades + membros */
.chat-left{
  width:260px;flex-shrink:0;border-right:1px solid #141414;
  display:flex;flex-direction:column;
  background:#0A0A0A;
}
.chat-cities{padding:12px 0;border-bottom:1px solid #141414}
.city-btn{
  display:block;width:100%;padding:10px 16px;
  background:none;border:none;color:#666;font-size:0.875rem;
  text-align:left;cursor:pointer;transition:all .15s;font-family:inherit;
  text-decoration:none;
}
.city-btn:hover{background:#111;color:#fff}
.city-btn.active{background:#111;color:#C9A84C;font-weight:600;
                  border-left:3px solid #C9A84C}
.city-title{font-size:0.68rem;font-weight:700;color:#333;
            letter-spacing:.08em;text-transform:uppercase;
            padding:12px 16px 6px}
.city-members{flex:1;overflow-y:auto;padding:0}
.city-members::-webkit-scrollbar{width:4px}
.city-members::-webkit-scrollbar-thumb{background:#1a1a1a;border-radius:2px}
.member-row{
  display:flex;align-items:center;gap:10px;
  padding:8px 14px;text-decoration:none;
  transition:background .15s;
}
.member-row:hover{background:#111}
.member-av{width:32px;height:32px;border-radius:50%;overflow:hidden;
            background:#1a1a1a;display:flex;align-items:center;
            justify-content:center;font-size:.9rem;color:#444;flex-shrink:0;
            position:relative;border:1px solid #222}
.member-av img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.member-online-dot{position:absolute;bottom:0;right:0;width:9px;height:9px;
                   border-radius:50%;background:#22c55e;border:2px solid #0A0A0A}
.member-name{font-size:0.8rem;color:#aaa;white-space:nowrap;
             overflow:hidden;text-overflow:ellipsis;flex:1}
.member-name.is-online{color:#fff}

/* Chat área principal */
.chat-main{flex:1;display:flex;flex-direction:column;min-width:0}
.chat-header{
  padding:14px 18px;border-bottom:1px solid #141414;
  display:flex;align-items:center;gap:12px;flex-shrink:0;
}
.chat-header-icon{
  width:40px;height:40px;border-radius:50%;
  background:linear-gradient(135deg,#7B2EFF,#C9A84C);
  display:flex;align-items:center;justify-content:center;font-size:1.2rem;
}
.chat-header-title{font-size:1rem;font-weight:700;color:#fff}
.chat-header-sub{font-size:0.72rem;color:#555}
.chat-messages{flex:1;overflow-y:auto;padding:16px 18px;display:flex;
               flex-direction:column;gap:3px}
.chat-messages::-webkit-scrollbar{width:4px}
.chat-messages::-webkit-scrollbar-thumb{background:#1a1a1a;border-radius:2px}

.msg-group{display:flex;flex-direction:column;gap:2px;margin-bottom:10px}
.msg-group.mine{align-items:flex-end}
.msg-group.theirs{align-items:flex-start}
.msg-author-row{display:flex;align-items:center;gap:7px;margin-bottom:4px}
.msg-av{width:26px;height:26px;border-radius:50%;overflow:hidden;
        background:#1a1a1a;display:flex;align-items:center;
        justify-content:center;font-size:.75rem;color:#555;flex-shrink:0;
        text-decoration:none;border:1px solid #222}
.msg-av img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.msg-author-name{font-size:0.72rem;font-weight:600;color:#C9A84C}
.msg-bubble{
  max-width:75%;padding:9px 13px;font-size:0.88rem;
  line-height:1.45;word-break:break-word;
}
.msg-group.theirs .msg-bubble{
  background:#1a1a1a;color:#e0e0e0;
  border-radius:4px 16px 16px 16px;
}
.msg-group.mine .msg-bubble{
  background:#7B2EFF;color:#fff;
  border-radius:16px 4px 16px 16px;
}

.chat-empty{flex:1;display:flex;flex-direction:column;align-items:center;
            justify-content:center;color:#333;text-align:center;gap:10px}

/* Input */
.chat-input-wrap{
  flex-shrink:0;display:flex;align-items:flex-end;gap:10px;
  padding:10px 16px 14px;border-top:1px solid #141414;
  padding-bottom:calc(14px + env(safe-area-inset-bottom));
}
.chat-input{
  flex:1;background:#151515;border:1px solid #222;border-radius:22px;
  color:#fff;font-size:0.9rem;font-family:inherit;
  padding:10px 16px;outline:none;resize:none;max-height:120px;line-height:1.4;
  transition:border-color .15s;
}
.chat-input:focus{border-color:#7B2EFF}
.chat-input::placeholder{color:#333}
.btn-send{
  width:40px;height:40px;border-radius:50%;flex-shrink:0;
  background:#7B2EFF;border:none;color:#fff;font-size:1.1rem;
  cursor:pointer;display:flex;align-items:center;justify-content:center;
  box-shadow:0 0 12px rgba(123,46,255,.35);transition:box-shadow .2s,transform .1s;
}
.btn-send:hover{box-shadow:0 0 20px rgba(123,46,255,.6)}
.btn-send:active{transform:scale(.92)}

/* DM link */
.dm-link{
  margin-left:auto;padding:6px 14px;background:#111;
  border:1px solid #222;border-radius:20px;color:#aaa;
  font-size:0.78rem;text-decoration:none;transition:all .15s;flex-shrink:0;
}
.dm-link:hover{color:#fff;border-color:#333}

@media(max-width:768px){
  .chat-left{display:none}
}
</style>

<div class="chat-layout">

  <!-- Painel esquerdo -->
  <div class="chat-left">
    <div class="chat-cities">
      <?php foreach (CHAT_CITIES as $city): ?>
        <a class="city-btn <?= $city === $selectedCity ? 'active' : '' ?>"
           href="/features/chat/index.php?city=<?= urlencode($city) ?>">
          💬 <?= htmlspecialchars($city, ENT_QUOTES, 'UTF-8') ?>
        </a>
      <?php endforeach; ?>
      <a class="city-btn" href="/features/chat/inbox.php">
        ✉️ Mensagens privadas
      </a>
    </div>

    <div class="city-title">Membros em <?= htmlspecialchars($selectedCity, ENT_QUOTES, 'UTF-8') ?></div>
    <div class="city-members">
      <?php if (empty($cityMembers)): ?>
        <div style="color:#333;font-size:.8rem;padding:12px 16px">Nenhum membro cadastrado aqui</div>
      <?php else: ?>
        <?php foreach ($cityMembers as $cm):
          $cmId     = (string)($cm['id'] ?? '');
          $cmLabel  = c61_cl_label($cm);
          $cmAvatar = trim((string)($cm['avatar_url'] ?? ''));
          $cmOnline = c61_is_online($cm['last_seen'] ?? null);
        ?>
        <a class="member-row" href="/features/profile/view.php?id=<?= urlencode($cmId) ?>">
          <div class="member-av" style="position:relative">
            <?php if ($cmAvatar !== ''): ?>
              <img src="<?= htmlspecialchars($cmAvatar, ENT_QUOTES, 'UTF-8') ?>" alt="">
            <?php else: ?>👤<?php endif; ?>
            <?php if ($cmOnline): ?><div class="member-online-dot"></div><?php endif; ?>
          </div>
          <span class="member-name <?= $cmOnline ? 'is-online' : '' ?>">
            <?= htmlspecialchars($cmLabel, ENT_QUOTES, 'UTF-8') ?>
          </span>
        </a>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- Chat principal -->
  <div class="chat-main">
    <div class="chat-header">
      <div class="chat-header-icon">💬</div>
      <div>
        <div class="chat-header-title"><?= htmlspecialchars($selectedCity, ENT_QUOTES, 'UTF-8') ?></div>
        <div class="chat-header-sub"><?= count($cityMembers) ?> membros nesta cidade</div>
      </div>
      <a class="dm-link" href="/features/chat/inbox.php">✉️ DMs</a>
    </div>

    <div class="chat-messages" id="chatMessages">
      <?php if (empty($messages)): ?>
        <div class="chat-empty">
          <div style="font-size:2rem;opacity:.3">💬</div>
          <div style="font-size:.875rem">Nenhuma mensagem ainda.<br>Seja o primeiro a falar!</div>
        </div>
      <?php else:
        $lastUid   = '';
        $groupOpen = false;
        foreach ($messages as $msg):
          $mUid    = (string)($msg['user_id'] ?? '');
          $mText   = (string)($msg['content']  ?? '');
          $isMine  = $mUid === $uid;
          $author  = $authorMap[$mUid] ?? [];
          $mLabel  = c61_cl_label($author);
          $mAvatar = trim((string)($author['avatar_url'] ?? ''));

          if ($mUid !== $lastUid):
            if ($groupOpen) echo '</div>';
            $groupClass = $isMine ? 'mine' : 'theirs';
            echo '<div class="msg-group ' . $groupClass . '">';
            $groupOpen = true;
            $lastUid   = $mUid;
            if (!$isMine):
      ?>
          <div class="msg-author-row">
            <a class="msg-av" href="/features/profile/view.php?id=<?= urlencode($mUid) ?>">
              <?php if ($mAvatar !== ''): ?>
                <img src="<?= htmlspecialchars($mAvatar, ENT_QUOTES, 'UTF-8') ?>" alt="">
              <?php else: ?>👤<?php endif; ?>
            </a>
            <span class="msg-author-name"><?= htmlspecialchars($mLabel, ENT_QUOTES, 'UTF-8') ?></span>
          </div>
      <?php endif; endif; ?>
          <div class="msg-bubble"><?= htmlspecialchars($mText, ENT_QUOTES, 'UTF-8') ?></div>
      <?php endforeach;
        if ($groupOpen) echo '</div>';
      endif; ?>
    </div>

    <div class="chat-input-wrap">
      <form method="POST" style="display:contents" id="msgForm">
        <input type="hidden" name="city" value="<?= htmlspecialchars($selectedCity, ENT_QUOTES, 'UTF-8') ?>">
        <textarea class="chat-input" name="content" id="msgInput"
                  placeholder="Mensagem em <?= htmlspecialchars($selectedCity, ENT_QUOTES, 'UTF-8') ?>..."
                  rows="1" maxlength="500" autocomplete="off"></textarea>
        <button class="btn-send" type="submit">&#10148;</button>
      </form>
    </div>
  </div>

</div>

<script>
var cm = document.getElementById('chatMessages');
if (cm) cm.scrollTop = cm.scrollHeight;

var inp = document.getElementById('msgInput');
inp.addEventListener('input', function(){
  this.style.height = 'auto';
  this.style.height = Math.min(this.scrollHeight, 120) + 'px';
});
inp.addEventListener('keydown', function(e){
  if (e.key === 'Enter' && !e.shiftKey){
    e.preventDefault();
    if (this.value.trim() !== '') document.getElementById('msgForm').submit();
  }
});
</script>

<?php require ROOT . '/config/layout_bottom.php'; ?>

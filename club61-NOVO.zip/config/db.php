<?php
require_once __DIR__ . '/supabase.php';

// ── cURL helper ──────────────────────────────────────────────────────────────
function sb_get(string $path, array $extra = []): ?array {
    $sk = SUPABASE_SERVICE_KEY;
    $ch = curl_init(SUPABASE_URL . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => array_merge([
            'apikey: ' . $sk,
            'Authorization: Bearer ' . $sk,
            'Accept: application/json',
        ], $extra),
    ]);
    $raw  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $code < 200 || $code >= 300) return null;
    $dec = json_decode($raw, true);
    return is_array($dec) ? $dec : null;
}

function sb_post(string $path, array $data): bool {
    $sk = SUPABASE_SERVICE_KEY;
    $ch = curl_init(SUPABASE_URL . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($data, JSON_UNESCAPED_UNICODE),
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
            'Content-Type: application/json',
            'Prefer: return=minimal',
        ],
    ]);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code >= 200 && $code < 300;
}

function sb_patch(string $path, array $data): bool {
    $sk = SUPABASE_SERVICE_KEY;
    $ch = curl_init(SUPABASE_URL . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_POSTFIELDS     => json_encode($data, JSON_UNESCAPED_UNICODE),
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
            'Content-Type: application/json',
            'Prefer: return=minimal',
        ],
    ]);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code >= 200 && $code < 300;
}

function sb_delete(string $path): bool {
    $sk = SUPABASE_SERVICE_KEY;
    $ch = curl_init(SUPABASE_URL . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'DELETE',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
            'Prefer: return=minimal',
        ],
    ]);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code >= 200 && $code < 300;
}

function sb_upload(string $bucket, string $filename, string $binary, string $mime): bool {
    $ch = curl_init(SUPABASE_URL . '/storage/v1/object/' . $bucket . '/' . $filename);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $binary,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
            'Content-Type: ' . $mime,
            'x-upsert: true',
        ],
    ]);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code >= 200 && $code < 300;
}

function sb_public_url(string $bucket, string $filename): string {
    return SUPABASE_URL . '/storage/v1/object/public/' . $bucket . '/' . $filename;
}

// ── Profile helpers ───────────────────────────────────────────────────────────
function get_profile(string $uid): ?array {
    $rows = sb_get('/rest/v1/profiles?id=eq.' . urlencode($uid) . '&select=id,username,display_id,avatar_url,bio,age,relationship_type,partner_age,cidade,tipo,role,status,last_seen');
    return $rows[0] ?? null;
}

function cl_label(array $p): string {
    $d = trim((string)($p['display_id'] ?? ''));
    $u = trim((string)($p['username']   ?? ''));
    if ($d !== '' && preg_match('/^CL\s*0*(\d+)$/i', $d, $m))
        return 'CL' . str_pad((string)(int)$m[1], 2, '0', STR_PAD_LEFT);
    return $u !== '' ? '@'.$u : 'Membro';
}

function is_online(?string $last_seen): bool {
    if (!$last_seen) return false;
    try {
        return (time() - (new DateTimeImmutable($last_seen))->getTimestamp()) < 120;
    } catch (Exception $e) {
        return false;
    }
}

function touch_last_seen(string $uid): void {
    sb_patch('/rest/v1/profiles?id=eq.' . urlencode($uid), [
        'last_seen' => gmdate('Y-m-d\TH:i:s\Z'),
    ]);
}

function is_admin(string $uid): bool {
    $row = get_profile($uid);
    return ($row['role'] ?? '') === 'admin' && ($row['status'] ?? 'active') !== 'banned';
}

function count_members(): int {
    $ch = curl_init(SUPABASE_URL . '/rest/v1/profiles?select=id');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER         => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            'apikey: ' . SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
            'Prefer: count=exact',
            'Range: 0-0',
        ],
    ]);
    $raw  = curl_exec($ch);
    curl_close($ch);
    if ($raw === false) return 0;
    if (preg_match('/Content-Range:\s*[^\/]*\/(\d+)/i', $raw, $m)) return (int)$m[1];
    return 0;
}

function time_ago(string $iso): string {
    try {
        $diff = time() - (new DateTimeImmutable($iso))->getTimestamp();
        if ($diff < 60)    return 'agora';
        if ($diff < 3600)  return floor($diff/60).'min';
        if ($diff < 86400) return floor($diff/3600).'h';
        return floor($diff/86400).'d';
    } catch (Exception $e) { return ''; }
}

function get_online_users(): array {
    $since = gmdate('Y-m-d\TH:i:s\Z', time() - 120);
    $rows  = sb_get('/rest/v1/profiles?select=id,display_id,username,avatar_url,cidade,last_seen&last_seen=gte.' . rawurlencode($since) . '&order=last_seen.desc&limit=30');
    return is_array($rows) ? $rows : [];
}

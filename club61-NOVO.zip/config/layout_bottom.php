</main>

<!-- Sidebar direita — membros online -->
<aside class="sidebar-right">
  <div class="online-title">🟢 Online agora</div>
  <?php if (empty($onlineMembers)): ?>
    <div class="online-empty">Nenhum membro online</div>
  <?php else: ?>
    <?php foreach ($onlineMembers as $om):
      $omLabel  = c61_cl_label($om);
      $omAvatar = trim((string)($om['avatar_url'] ?? ''));
      $omCity   = trim((string)($om['cidade']     ?? ''));
      $omId     = (string)($om['id'] ?? '');
      $omOnline = c61_is_online($om['last_seen'] ?? null);
    ?>
    <a class="online-member" href="/features/profile/view.php?id=<?= urlencode($omId) ?>">
      <div class="online-avatar-wrap">
        <div class="online-avatar">
          <?php if ($omAvatar !== ''): ?>
            <img src="<?= htmlspecialchars($omAvatar, ENT_QUOTES, 'UTF-8') ?>" alt="">
          <?php else: ?>👤<?php endif; ?>
        </div>
        <?php if ($omOnline): ?><div class="online-dot"></div><?php endif; ?>
      </div>
      <div class="online-info">
        <div class="online-name"><?= htmlspecialchars($omLabel, ENT_QUOTES, 'UTF-8') ?></div>
        <?php if ($omCity !== ''): ?>
          <div class="online-city"><?= htmlspecialchars($omCity, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
      </div>
    </a>
    <?php endforeach; ?>
  <?php endif; ?>
</aside>

</div><!-- .app-layout -->

<!-- Bottom nav mobile -->
<nav class="bottom-nav">
  <a class="bnav-btn <?= ($activePage??'') === 'feed'    ? 'active' : '' ?>" href="/features/feed/index.php">
    <span>🏠</span><span>Feed</span>
  </a>
  <a class="bnav-btn <?= ($activePage??'') === 'chat'    ? 'active' : '' ?>" href="/features/chat/index.php">
    <span>💬</span><span>Chat</span>
  </a>
  <a class="bnav-post" href="#" id="openPostModal">＋</a>
  <a class="bnav-btn <?= ($activePage??'') === 'profile' ? 'active' : '' ?>" href="/features/profile/index.php">
    <span>👤</span><span>Perfil</span>
  </a>
  <a class="bnav-btn <?= ($activePage??'') === 'story'   ? 'active' : '' ?>" href="/features/stories/upload.php">
    <span>📷</span><span>Story</span>
  </a>
</nav>

</body>
</html>

<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();

$uid      = c61_uid();
$otherId  = trim($_GET['with'] ?? '');
if ($otherId === '' || $otherId === $uid) { header('Location: /features/chat/inbox.php'); exit; }

$pageTitle  = 'Mensagem privada';
$activePage = 'chat';

// Enviar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = trim($_POST['content'] ?? '');
    if ($content !== '' && mb_strlen($content, 'UTF-8') <= 500) {
        sb_post('/rest/v1/direct_messages', [
            'sender_id'   => $uid,
            'receiver_id' => $otherId,
            'content'     => $content,
        ]);
    }
    header('Location: /features/chat/dm.php?with=' . urlencode($otherId));
    exit;
}

// Marcar como lidas
sb_patch('/rest/v1/direct_messages?sender_id=eq.' . urlencode($otherId) . '&receiver_id=eq.' . urlencode($uid) . '&read_at=is.null',
    ['read_at' => gmdate('Y-m-d\TH:i:s\Z')]);

// Buscar mensagens
$messages = sb_get('/rest/v1/direct_messages?or=(and(sender_id.eq.' . urlencode($uid) . ',receiver_id.eq.' . urlencode($otherId) . '),and(sender_id.eq.' . urlencode($otherId) . ',receiver_id.eq.' . urlencode($uid) . '))&select=id,sender_id,content,created_at&order=created_at.asc&limit=100');

$otherProfile = c61_get_profile($otherId);
$otherLabel   = c61_cl_label($otherProfile);
$otherAvatar  = trim((string)($otherProfile['avatar_url'] ?? ''));
$otherOnline  = c61_is_online($otherProfile['last_seen'] ?? null);

require ROOT . '/config/layout_top.php';
?>
<style>
.dm-layout{display:flex;flex-direction:column;height:calc(100vh - 52px)}
.dm-header{flex-shrink:0;display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid #141414}
.dm-av{width:38px;height:38px;border-radius:50%;overflow:hidden;background:#1a1a1a;
        display:flex;align-items:center;justify-content:center;font-size:1rem;color:#444;
        flex-shrink:0;text-decoration:none;border:1px solid #222;position:relative}
.dm-av img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.dm-online{position:absolute;bottom:0;right:0;width:10px;height:10px;border-radius:50%;
           background:#22c55e;border:2px solid #0A0A0A}
.dm-messages{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:3px}
.dm-messages::-webkit-scrollbar{width:4px}
.dm-messages::-webkit-scrollbar-thumb{background:#1a1a1a;border-radius:2px}
.dm-msg-group{display:flex;flex-direction:column;gap:2px;margin-bottom:10px}
.dm-msg-group.mine{align-items:flex-end}
.dm-msg-group.theirs{align-items:flex-start}
.dm-bubble{max-width:75%;padding:10px 14px;font-size:.88rem;line-height:1.45;word-break:break-word}
.dm-msg-group.theirs .dm-bubble{background:#1e1e1e;color:#e0e0e0;border-radius:4px 18px 18px 18px}
.dm-msg-group.mine .dm-bubble{background:#7B2EFF;color:#fff;border-radius:18px 4px 18px 18px}
.dm-input-wrap{flex-shrink:0;display:flex;align-items:flex-end;gap:10px;padding:10px 14px;
               padding-bottom:calc(10px + env(safe-area-inset-bottom));border-top:1px solid #141414}
.dm-input{flex:1;background:#151515;border:1px solid #222;border-radius:22px;color:#fff;
           font-size:.9rem;font-family:inherit;padding:10px 16px;outline:none;
           resize:none;max-height:120px;line-height:1.4;transition:border-color .15s}
.dm-input:focus{border-color:#7B2EFF}
.dm-input::placeholder{color:#333}
.dm-send{width:40px;height:40px;border-radius:50%;flex-shrink:0;background:#7B2EFF;
          border:none;color:#fff;font-size:1.1rem;cursor:pointer;
          display:flex;align-items:center;justify-content:center;
          box-shadow:0 0 12px rgba(123,46,255,.35);transition:box-shadow .2s,transform .1s}
.dm-send:hover{box-shadow:0 0 20px rgba(123,46,255,.6)}
.dm-send:active{transform:scale(.92)}
.back-link{color:#aaa;text-decoration:none;font-size:1.2rem;padding:4px}
.back-link:hover{color:#fff}
</style>

<div class="dm-layout">
  <div class="dm-header">
    <a class="back-link" href="/features/chat/inbox.php">&#8592;</a>
    <a class="dm-av" href="/features/profile/view.php?id=<?= urlencode($otherId) ?>">
      <?php if ($otherAvatar !== ''): ?><img src="<?= htmlspecialchars($otherAvatar, ENT_QUOTES, 'UTF-8') ?>" alt=""><?php else: ?>👤<?php endif; ?>
      <?php if ($otherOnline): ?><div class="dm-online"></div><?php endif; ?>
    </a>
    <div>
      <div style="font-size:.95rem;font-weight:700;color:#fff"><?= htmlspecialchars($otherLabel, ENT_QUOTES, 'UTF-8') ?></div>
      <div style="font-size:.7rem;color:#555"><?= $otherOnline ? '🟢 Online agora' : 'Mensagem privada' ?></div>
    </div>
  </div>

  <div class="dm-messages" id="dmMessages">
    <?php
    $lastSid   = '';
    $groupOpen = false;
    foreach ($messages as $msg):
      $sid    = (string)($msg['sender_id'] ?? '');
      $text   = (string)($msg['content']   ?? '');
      $isMine = $sid === $uid;
      if ($sid !== $lastSid):
        if ($groupOpen) echo '</div>';
        echo '<div class="dm-msg-group ' . ($isMine ? 'mine' : 'theirs') . '">';
        $groupOpen = true;
        $lastSid   = $sid;
      endif;
    ?>
      <div class="dm-bubble"><?= htmlspecialchars($text, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endforeach;
    if ($groupOpen) echo '</div>'; ?>
  </div>

  <div class="dm-input-wrap">
    <form method="POST" style="display:contents" id="dmForm">
      <textarea class="dm-input" name="content" id="dmInput"
                placeholder="Mensagem para <?= htmlspecialchars($otherLabel, ENT_QUOTES, 'UTF-8') ?>..."
                rows="1" maxlength="500" autocomplete="off"></textarea>
      <button class="dm-send" type="submit">&#10148;</button>
    </form>
  </div>
</div>

<script>
var dm = document.getElementById('dmMessages');
if (dm) dm.scrollTop = dm.scrollHeight;
var inp = document.getElementById('dmInput');
inp.addEventListener('input', function(){ this.style.height='auto'; this.style.height=Math.min(this.scrollHeight,120)+'px'; });
inp.addEventListener('keydown', function(e){
  if (e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); if(this.value.trim()!=='') document.getElementById('dmForm').submit(); }
});
</script>

<?php require ROOT . '/config/layout_bottom.php'; ?>

<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/config/supabase.php';
require_once __DIR__ . '/config/db.php';

if (empty($_SESSION['access_token']) || empty($_SESSION['user_id'])) {
    header('Location: /features/auth/login.php');
    exit;
}

touch_last_seen((string)$_SESSION['user_id']);

<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();

$pageTitle  = 'Novo Story';
$activePage = 'story';
$uid        = c61_uid();
$status     = (string)($_GET['status']  ?? '');
$message    = (string)($_GET['message'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $file = $_FILES['story_image'] ?? null;
    if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
        header('Location: /features/stories/upload.php?status=error&message=' . urlencode('Erro ao enviar arquivo.'));
        exit;
    }
    $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $mime    = mime_content_type($file['tmp_name']);
    if (!isset($allowed[$mime]) || $file['size'] > 8*1024*1024) {
        header('Location: /features/stories/upload.php?status=error&message=' . urlencode('Formato ou tamanho inválido.'));
        exit;
    }
    $fn     = 'story_' . preg_replace('/[^a-z0-9]/', '', $uid) . '_' . uniqid() . '.' . $allowed[$mime];
    $binary = file_get_contents($file['tmp_name']);
    $code   = sb_upload('stories', $fn, $binary, $mime);
    if ($code >= 200 && $code < 300) {
        $expiresAt = gmdate('Y-m-d\TH:i:s\Z', time() + 86400);
        $res = sb_post('/rest/v1/stories', [
            'user_id'    => $uid,
            'image_url'  => sb_public_url('stories', $fn),
            'expires_at' => $expiresAt,
        ]);
        if ($res >= 200 && $res < 300) {
            header('Location: /features/stories/upload.php?status=ok&message=' . urlencode('Story publicado! Fica disponível por 24h.'));
            exit;
        }
        header('Location: /features/stories/upload.php?status=error&message=' . urlencode('Erro ao registrar story. HTTP ' . $res));
        exit;
    }
    header('Location: /features/stories/upload.php?status=error&message=' . urlencode('Erro ao enviar para o Storage.'));
    exit;
}

require ROOT . '/config/layout_top.php';
?>
<style>
.story-upload-wrap{max-width:480px;margin:0 auto;padding:24px 20px}
.story-upload-card{background:#111;border:1px solid #1e1e1e;border-radius:16px;padding:28px 24px}
.story-title{font-size:1.1rem;font-weight:700;color:#C9A84C;text-align:center;margin-bottom:20px}
.upload-zone{border:2px dashed #2a2a2a;border-radius:14px;padding:48px 20px;text-align:center;
             color:#555;cursor:pointer;background:#0d0d0d;transition:border-color .2s;margin-bottom:16px}
.upload-zone:hover{border-color:#7B2EFF;color:#aaa}
#storyPreview{display:none;width:100%;max-height:400px;object-fit:contain;border-radius:12px;
              margin-bottom:16px;border:1px solid #1e1e1e;background:#0d0d0d}
</style>

<div class="story-upload-wrap">
  <?php if ($status !== ''): ?>
    <div class="alert <?= $status ?>"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
  <?php endif; ?>
  <div class="story-upload-card">
    <div class="story-title">📷 Novo Story</div>
    <form method="POST" enctype="multipart/form-data" id="storyForm">
      <input type="file" id="storyFile" name="story_image" accept="image/jpeg,image/png,image/webp" required style="display:none">
      <img id="storyPreview" src="" alt="Prévia">
      <div class="upload-zone" id="uploadZone">
        <div style="font-size:2.5rem;margin-bottom:10px;opacity:.5">📷</div>
        <div style="font-size:.875rem">Toque para escolher uma foto</div>
        <div style="font-size:.75rem;color:#333;margin-top:6px">JPG, PNG, WEBP · máx 8MB · expira em 24h</div>
      </div>
      <button class="btn-primary" type="submit" id="btnSend" style="width:100%;justify-content:center">
        Publicar story
      </button>
    </form>
  </div>
</div>

<script>
var zone = document.getElementById('uploadZone');
var file = document.getElementById('storyFile');
var prev = document.getElementById('storyPreview');
var btn  = document.getElementById('btnSend');
zone.addEventListener('click', function(){ file.click(); });
file.addEventListener('change', function(){
  if (this.files && this.files[0]) {
    var r = new FileReader();
    r.onload = function(e){ prev.src = e.target.result; prev.style.display='block'; zone.style.display='none'; };
    r.readAsDataURL(this.files[0]);
  }
});
document.getElementById('storyForm').addEventListener('submit', function(){ btn.disabled=true; btn.textContent='Enviando...'; });
</script>

<?php require ROOT . '/config/layout_bottom.php'; ?>

<?php
// config/layout.php — componentes reutilizáveis
function render_topnav(string $active = 'feed'): void {
    $uid     = (string)($_SESSION['user_id'] ?? '');
    $isAdmin = $uid !== '' && is_admin($uid);
    $links   = [
        'feed'     => ['/features/feed/index.php',    '🏠', 'Feed'],
        'chat'     => ['/features/chat/index.php',    '💬', 'Chat'],
        'profile'  => ['/features/profile/index.php', '👤', 'Perfil'],
        'settings' => ['/features/settings/index.php','⚙️', 'Config'],
    ];
    echo '<nav class="topnav">';
    echo '<a class="topnav-brand" href="/features/feed/index.php">Club61</a>';
    echo '<div class="topnav-links">';
    foreach ($links as $key => [$href, $icon, $label]) {
        $cls = $key === $active ? 'active' : '';
        echo '<a class="tnav-link '.$cls.'" href="'.htmlspecialchars($href).'">'.$icon.' '.$label.'</a>';
    }
    if ($isAdmin) {
        echo '<a class="tnav-link tnav-admin" href="/features/admin/index.php">🛡 Admin</a>';
    }
    echo '<a class="tnav-link" href="/features/auth/logout.php">🚪</a>';
    echo '</div></nav>';
}

function render_sidebar(): void {
    $online = get_online_users();
    echo '<aside class="sidebar">';
    echo '<div class="sidebar-title">🟢 Online agora</div>';
    if (empty($online)) {
        echo '<div class="sidebar-empty">Nenhum membro online</div>';
    } else {
        foreach ($online as $u) {
            $label  = cl_label($u);
            $avatar = trim((string)($u['avatar_url'] ?? ''));
            $cidade = trim((string)($u['cidade']     ?? ''));
            $uid    = (string)($u['id'] ?? '');
            echo '<a class="sidebar-user" href="/features/profile/view.php?id='.urlencode($uid).'">';
            echo '<div class="su-avatar">';
            if ($avatar !== '') {
                echo '<img src="'.htmlspecialchars($avatar).'" alt="">';
            } else {
                echo '👤';
            }
            echo '<span class="online-dot"></span>';
            echo '</div>';
            echo '<div class="su-info">';
            echo '<div class="su-name">'.htmlspecialchars($label).'</div>';
            if ($cidade !== '') echo '<div class="su-cidade">'.htmlspecialchars($cidade).'</div>';
            echo '</div>';
            echo '</a>';
        }
    }
    echo '</aside>';
}

function render_css(): void { ?>
<style>
:root{
  --bg:#0A0A0A;--card:#111;--border:#1a1a1a;
  --gold:#C9A84C;--purple:#7B2EFF;--red:#ff4b6e;
  --text:#fff;--muted:#aaa;--dim:#555;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{min-height:100%;background:var(--bg);color:var(--text);
  font-family:'Segoe UI',system-ui,sans-serif;-webkit-font-smoothing:antialiased}

/* ── Topnav ── */
.topnav{
  position:sticky;top:0;z-index:200;
  background:var(--bg);border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:space-between;
  padding:0 20px;height:54px;
}
.topnav-brand{font-size:1.4rem;font-weight:800;color:var(--gold);
  letter-spacing:3px;text-decoration:none}
.topnav-links{display:flex;align-items:center;gap:4px}
.tnav-link{padding:6px 10px;border-radius:8px;text-decoration:none;
  color:var(--muted);font-size:0.85rem;font-weight:500;transition:all .15s}
.tnav-link:hover,.tnav-link.active{background:var(--card);color:var(--text)}
.tnav-admin{color:var(--gold)}

/* ── Layout com sidebar ── */
.page-wrap{display:flex;max-width:1100px;margin:0 auto;padding:24px 16px;gap:24px}
.main-col{flex:1;min-width:0}
.sidebar{width:240px;flex-shrink:0}
@media(max-width:768px){.sidebar{display:none}.page-wrap{padding:16px 12px}}

/* ── Sidebar ── */
.sidebar-title{font-size:0.72rem;font-weight:700;color:var(--dim);
  letter-spacing:.08em;text-transform:uppercase;margin-bottom:12px}
.sidebar-empty{color:var(--dim);font-size:0.85rem}
.sidebar-user{display:flex;align-items:center;gap:10px;padding:8px;
  border-radius:10px;text-decoration:none;transition:background .15s;margin-bottom:4px}
.sidebar-user:hover{background:var(--card)}
.su-avatar{position:relative;width:36px;height:36px;border-radius:50%;
  background:#1a1a1a;overflow:visible;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;font-size:1.1rem}
.su-avatar img{width:36px;height:36px;border-radius:50%;object-fit:cover}
.online-dot{position:absolute;bottom:0;right:0;width:10px;height:10px;
  background:#22c55e;border-radius:50%;border:2px solid var(--bg)}
.su-info{min-width:0}
.su-name{font-size:0.85rem;font-weight:600;color:var(--text);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.su-cidade{font-size:0.72rem;color:var(--dim)}

/* ── Cards ── */
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;overflow:hidden}
.card+.card{margin-top:20px}

/* ── Botões ── */
.btn{display:inline-flex;align-items:center;gap:6px;padding:9px 18px;
  border-radius:8px;border:none;font-size:0.875rem;font-weight:600;
  cursor:pointer;transition:all .2s;text-decoration:none}
.btn-primary{background:var(--purple);color:#fff;box-shadow:0 0 12px rgba(123,46,255,.3)}
.btn-primary:hover{box-shadow:0 0 22px rgba(123,46,255,.55)}
.btn-ghost{background:var(--card);color:var(--muted);border:1px solid var(--border)}
.btn-ghost:hover{color:var(--text);border-color:#333}
.btn-danger{background:rgba(255,75,110,.1);color:var(--red);border:1px solid rgba(255,75,110,.3)}
.btn-danger:hover{background:rgba(255,75,110,.2)}
.btn-sm{padding:5px 12px;font-size:0.78rem}
.btn-full{width:100%;justify-content:center}

/* ── Forms ── */
.field{margin-bottom:16px}
.field label{display:block;font-size:0.72rem;font-weight:600;color:var(--dim);
  text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px}
.field input,.field textarea,.field select{
  width:100%;background:#151515;border:1px solid #222;border-radius:8px;
  color:var(--text);padding:10px 14px;font-size:0.9rem;outline:none;
  font-family:inherit;transition:border-color .15s}
.field input:focus,.field textarea:focus,.field select:focus{border-color:var(--purple)}
.field input::placeholder,.field textarea::placeholder{color:#333}
.field textarea{resize:none}

/* ── Alert ── */
.alert{padding:10px 14px;border-radius:8px;font-size:0.85rem;margin-bottom:16px}
.alert-ok{background:#1a3a1f;color:#69db7c;border:1px solid #2f6e3b}
.alert-error{background:#3a1a1a;color:#ff6b6b;border:1px solid #7e2a2a}

/* ── Stories ── */
.stories-bar{background:var(--bg);border-bottom:1px solid var(--border)}
.stories-scroll{display:flex;gap:14px;overflow-x:auto;padding:12px 16px 14px;
  scrollbar-width:none}
.stories-scroll::-webkit-scrollbar{display:none}
.story-item{flex:0 0 auto;display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer}
.story-ring{width:62px;height:62px;border-radius:50%;padding:2px;
  background:linear-gradient(45deg,#f09433,#e6683c,#dc2743,#cc2366,#bc1888);
  display:flex;align-items:center;justify-content:center;text-decoration:none}
.story-ring--add{background:none;border:2px dashed #333;padding:0}
.story-ring--add:hover{border-color:var(--purple)}
.story-inner{width:100%;height:100%;border-radius:50%;background:var(--card);
  overflow:hidden;display:flex;align-items:center;justify-content:center}
.story-inner img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.story-label{font-size:0.66rem;color:var(--muted);max-width:62px;
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center}

/* ── Posts ── */
.post-header{display:flex;align-items:center;gap:10px;padding:12px 14px}
.post-avatar{width:36px;height:36px;border-radius:50%;overflow:hidden;
  background:#1a1a1a;display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;flex-shrink:0;text-decoration:none;border:1px solid #222}
.post-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.post-author{flex:1;min-width:0;text-decoration:none}
.post-author-name{font-size:0.875rem;font-weight:600;color:var(--text)}
.post-author-time{font-size:0.72rem;color:var(--dim)}
.post-img{width:100%;display:block;max-height:520px;object-fit:cover}
.post-actions{display:flex;align-items:center;gap:4px;padding:10px 14px 6px}
.like-btn{background:none;border:none;cursor:pointer;font-size:1.5rem;
  color:var(--muted);padding:4px 6px;transition:color .15s}
.like-btn:hover{color:var(--text)}
.like-btn.liked{color:var(--red)}
.post-caption{padding:2px 14px 10px;font-size:0.875rem;color:#d4d4d4;line-height:1.45}
.post-caption strong{color:var(--text);margin-right:6px}
.post-time{font-size:0.72rem;color:var(--dim);padding:0 14px 10px}
.post-comments{padding:0 14px 14px}
.comment-line{font-size:0.85rem;color:#ccc;margin-bottom:4px}
.comment-line strong{color:var(--text);margin-right:5px}
.comment-form{display:flex;gap:8px;align-items:center;margin-top:8px}
.comment-input{flex:1;background:#0d0d0d;border:none;border-bottom:1px solid #222;
  color:var(--text);padding:6px 4px;font-size:0.85rem;outline:none;font-family:inherit}
.comment-submit{background:none;border:none;color:var(--purple);
  font-weight:700;font-size:0.85rem;cursor:pointer}

/* ── Profile ── */
.profile-header{text-align:center;padding:32px 20px 24px}
.profile-pic{width:90px;height:90px;border-radius:50%;object-fit:cover;
  background:#1a1a1a;margin:0 auto 16px;display:block;border:3px solid var(--border)}
.profile-cl{font-size:1.4rem;font-weight:800;color:var(--gold);margin-bottom:4px}
.profile-tipo{font-size:0.85rem;color:var(--muted)}
.profile-cidade{font-size:0.85rem;color:var(--dim)}
.profile-bio{font-size:0.875rem;color:var(--muted);line-height:1.5;margin:10px auto;max-width:300px}
.profile-age{font-size:0.78rem;color:var(--dim);margin-top:4px}
.profile-stats{display:flex;justify-content:center;gap:32px;margin:16px 0}
.stat-val{font-size:1.2rem;font-weight:700;color:var(--text);display:block}
.stat-lbl{font-size:0.72rem;color:var(--dim)}
.profile-actions{display:flex;justify-content:center;gap:10px;margin-top:16px}
.profile-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px}
.profile-grid-item{position:relative;aspect-ratio:1;overflow:hidden;background:#1a1a1a}
.profile-grid-item img{width:100%;height:100%;object-fit:cover;display:block;transition:opacity .15s}
.profile-grid-item:hover img{opacity:.8}
.profile-grid-del{position:absolute;top:4px;right:4px;background:rgba(0,0,0,.75);
  border:none;color:#fff;border-radius:50%;width:22px;height:22px;
  cursor:pointer;font-size:.7rem;display:flex;align-items:center;justify-content:center}

/* ── Chat UOL style ── */
.chat-layout{display:flex;height:calc(100vh - 54px)}
.chat-sidebar{width:220px;flex-shrink:0;background:var(--card);
  border-right:1px solid var(--border);overflow-y:auto}
.chat-rooms{display:flex;flex-direction:column}
.chat-room-title{font-size:0.7rem;font-weight:700;color:var(--dim);
  text-transform:uppercase;letter-spacing:.08em;padding:14px 16px 6px}
.chat-room-item{display:flex;align-items:center;gap:10px;padding:10px 16px;
  cursor:pointer;transition:background .15s;text-decoration:none;
  border-bottom:1px solid var(--border)}
.chat-room-item:hover,.chat-room-item.active{background:#1a1a1a}
.room-icon{font-size:1.2rem}
.room-name{font-size:0.875rem;font-weight:600;color:var(--text)}
.room-count{font-size:0.72rem;color:var(--dim)}
.chat-room-users{padding:8px 12px}
.room-user-item{display:flex;align-items:center;gap:8px;padding:5px 4px;
  border-radius:6px;text-decoration:none;transition:background .15s}
.room-user-item:hover{background:#1a1a1a}
.rui-avatar{width:28px;height:28px;border-radius:50%;background:#222;
  overflow:hidden;flex-shrink:0;display:flex;align-items:center;
  justify-content:center;font-size:.85rem;position:relative}
.rui-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.rui-dot{position:absolute;bottom:0;right:0;width:8px;height:8px;
  background:#22c55e;border-radius:50%;border:1.5px solid var(--card)}
.rui-name{font-size:0.8rem;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.chat-main{flex:1;display:flex;flex-direction:column;min-width:0}
.chat-topbar{padding:12px 16px;border-bottom:1px solid var(--border);
  display:flex;align-items:center;gap:10px;background:var(--bg)}
.chat-topbar-name{font-size:1rem;font-weight:700;color:var(--text)}
.chat-topbar-sub{font-size:0.75rem;color:var(--dim)}
.chat-messages{flex:1;overflow-y:auto;padding:16px;display:flex;
  flex-direction:column;gap:3px}
.chat-messages::-webkit-scrollbar{width:4px}
.chat-messages::-webkit-scrollbar-thumb{background:#222;border-radius:2px}
.msg-group{display:flex;flex-direction:column;gap:2px;margin-bottom:10px}
.msg-group.mine{align-items:flex-end}
.msg-group.theirs{align-items:flex-start}
.msg-author{display:flex;align-items:center;gap:6px;margin-bottom:4px}
.msg-author-avatar{width:26px;height:26px;border-radius:50%;background:#222;
  overflow:hidden;display:flex;align-items:center;justify-content:center;font-size:.8rem}
.msg-author-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.msg-author-name{font-size:0.72rem;font-weight:600;color:var(--gold)}
.msg-bubble{max-width:75%;padding:9px 13px;font-size:0.9rem;
  line-height:1.45;word-break:break-word}
.msg-group.theirs .msg-bubble{background:#1e1e1e;color:#e0e0e0;
  border-radius:4px 16px 16px 16px}
.msg-group.mine .msg-bubble{background:var(--purple);color:#fff;
  border-radius:16px 4px 16px 16px}
.msg-media img{max-width:220px;border-radius:10px;margin-top:6px;display:block;cursor:pointer}
.msg-media video{max-width:220px;border-radius:10px;margin-top:6px;display:block}
.date-div{text-align:center;font-size:0.68rem;color:var(--dim);margin:8px 0}
.chat-input-wrap{display:flex;align-items:flex-end;gap:8px;
  padding:10px 14px 12px;border-top:1px solid var(--border);background:var(--bg)}
.chat-textarea{flex:1;background:#151515;border:1px solid #222;border-radius:20px;
  color:var(--text);font-size:0.9rem;font-family:inherit;
  padding:10px 16px;outline:none;resize:none;max-height:120px;
  line-height:1.4;transition:border-color .15s}
.chat-textarea:focus{border-color:var(--purple)}
.chat-textarea::placeholder{color:#333}
.chat-send{width:38px;height:38px;border-radius:50%;flex-shrink:0;
  background:var(--purple);border:none;color:#fff;font-size:1rem;
  cursor:pointer;display:flex;align-items:center;justify-content:center;
  transition:box-shadow .2s}
.chat-send:hover{box-shadow:0 0 16px rgba(123,46,255,.55)}
.emoji-btn{background:none;border:none;font-size:1.3rem;cursor:pointer;
  color:var(--dim);padding:4px;transition:color .15s;flex-shrink:0}
.emoji-btn:hover{color:var(--text)}
.file-btn{background:none;border:none;font-size:1.2rem;cursor:pointer;
  color:var(--dim);padding:4px;transition:color .15s;flex-shrink:0}
.file-btn:hover{color:var(--text)}
.emoji-panel{display:none;position:absolute;bottom:100%;left:0;right:0;
  background:var(--card);border:1px solid var(--border);border-radius:14px 14px 0 0;
  padding:12px;z-index:50;max-height:240px;overflow-y:auto}
.emoji-panel.open{display:block}
.emoji-cat{font-size:0.65rem;color:var(--dim);text-transform:uppercase;
  letter-spacing:.08em;margin-bottom:6px;margin-top:8px}
.emoji-cat:first-child{margin-top:0}
.emoji-grid{display:flex;flex-wrap:wrap;gap:4px}
.emoji-pick{background:#1a1a1a;border:none;border-radius:6px;
  font-size:1.2rem;width:34px;height:34px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;transition:background .15s}
.emoji-pick:hover{background:#2a2a2a}
.media-preview{display:flex;align-items:center;gap:8px;padding:6px 10px;
  background:#151515;border-radius:10px;margin-bottom:6px}
.media-preview img{max-width:56px;max-height:56px;border-radius:6px}
.media-preview-name{font-size:.8rem;color:var(--muted)}
.media-preview-del{background:none;border:none;color:var(--red);cursor:pointer;font-size:1rem;margin-left:auto}

/* ── Admin ── */
.admin-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:28px}
@media(max-width:600px){.admin-stats{grid-template-columns:repeat(2,1fr)}}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:12px;
  padding:18px;text-align:center}
.stat-num{font-size:2rem;font-weight:800;color:var(--gold)}
.stat-lbl2{font-size:.72rem;color:var(--dim);margin-top:4px;text-transform:uppercase;letter-spacing:.04em}
.tabs{display:flex;gap:4px;background:var(--card);border-radius:10px;
  padding:4px;margin-bottom:20px;border:1px solid var(--border)}
.tab-btn{flex:1;padding:8px;border:none;border-radius:7px;background:none;
  color:var(--dim);font-size:.8rem;font-weight:600;cursor:pointer;transition:all .15s}
.tab-btn.active{background:#1e1e1e;color:var(--text)}
.tab-content{display:none}
.tab-content.active{display:block}
.table-wrap{overflow-x:auto;border-radius:10px;border:1px solid var(--border)}
table{width:100%;border-collapse:collapse;font-size:.85rem}
th{background:var(--card);color:var(--dim);font-size:.7rem;font-weight:600;
  letter-spacing:.06em;text-transform:uppercase;padding:10px 14px;
  text-align:left;border-bottom:1px solid var(--border)}
td{padding:10px 14px;border-bottom:1px solid #0f0f0f;vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:#0d0d0d}
.badge{display:inline-block;padding:2px 8px;border-radius:6px;
  font-size:.68rem;font-weight:700;letter-spacing:.04em}
.badge-admin{background:rgba(201,168,76,.15);color:var(--gold);border:1px solid rgba(201,168,76,.3)}
.badge-member{background:#1a1a1a;color:var(--dim);border:1px solid #222}
.badge-ok{background:#1a3a1f;color:#69db7c;border:1px solid #2f6e3b}
.badge-used{background:#1a1a1a;color:var(--dim);border:1px solid #222}
.badge-revoked{background:rgba(255,107,107,.1);color:#ff6b6b;border:1px solid rgba(255,107,107,.3)}
.invite-code{font-family:monospace;font-size:1rem;font-weight:700;color:var(--gold);
  background:#0d0d0d;border:1px solid var(--border);border-radius:8px;
  padding:8px 12px;cursor:pointer;transition:border-color .15s;user-select:all}
.invite-code:hover{border-color:var(--purple)}
.invite-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px}
.invite-card{background:var(--card);border:1px solid var(--border);
  border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:8px}

/* ── Auth ── */
.auth-wrap{min-height:100vh;display:flex;align-items:center;
  justify-content:center;padding:24px 16px}
.auth-card{background:var(--card);border:1px solid var(--border);
  border-radius:12px;padding:40px 32px;width:100%;max-width:420px}
.auth-brand{font-size:2rem;font-weight:800;color:var(--gold);
  text-align:center;letter-spacing:3px;margin-bottom:6px}
.auth-sub{text-align:center;color:var(--dim);font-size:.85rem;margin-bottom:28px}
</style>
<?php } ?>

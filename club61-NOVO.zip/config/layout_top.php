<?php
// layout.php — incluir no topo de cada página assim:
// $pageTitle = 'Feed'; $activePage = 'feed';
// require ROOT . '/config/layout_top.php';
// ... conteúdo ...
// require ROOT . '/config/layout_bottom.php';

$onlineMembers = c61_online_members();
c61_touch_last_seen();
$currentUid = c61_uid();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title><?= htmlspecialchars($pageTitle ?? 'Club61', ENT_QUOTES, 'UTF-8') ?> — Club61</title>
<style>
/* ── Reset ── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{height:100%;scroll-behavior:smooth}
body{background:#0A0A0A;color:#fff;font-family:'Segoe UI',system-ui,sans-serif;
     min-height:100vh;-webkit-font-smoothing:antialiased}

/* ── Layout principal ── */
.app-layout{display:flex;min-height:100vh;max-width:1200px;margin:0 auto}

/* ── Sidebar esquerda (nav) ── */
.sidebar-left{
  width:220px;flex-shrink:0;
  position:sticky;top:0;height:100vh;
  display:flex;flex-direction:column;
  padding:24px 16px;border-right:1px solid #1a1a1a;
  background:#0A0A0A;
}
.sidebar-brand{
  font-size:1.6rem;font-weight:800;
  color:#C9A84C;letter-spacing:3px;
  text-decoration:none;margin-bottom:32px;
  display:block;
}
.nav-item{
  display:flex;align-items:center;gap:12px;
  padding:12px 14px;border-radius:12px;
  text-decoration:none;color:#666;
  font-size:0.9rem;font-weight:500;
  transition:all .15s;margin-bottom:4px;
}
.nav-item:hover{background:#111;color:#fff}
.nav-item.active{background:#111;color:#fff}
.nav-item .icon{font-size:1.2rem;width:22px;text-align:center}
.nav-bottom{margin-top:auto}
.nav-item.danger:hover{color:#ff6b6b;background:rgba(255,107,107,.08)}

/* ── Conteúdo central ── */
.main-content{
  flex:1;min-width:0;
  border-right:1px solid #1a1a1a;
}

/* ── Sidebar direita (online) ── */
.sidebar-right{
  width:280px;flex-shrink:0;
  position:sticky;top:0;height:100vh;overflow-y:auto;
  padding:20px 16px;background:#0A0A0A;
}
.sidebar-right::-webkit-scrollbar{width:4px}
.sidebar-right::-webkit-scrollbar-thumb{background:#1a1a1a;border-radius:2px}

.online-title{
  font-size:0.72rem;font-weight:700;color:#555;
  letter-spacing:.08em;text-transform:uppercase;
  margin-bottom:16px;
}
.online-member{
  display:flex;align-items:center;gap:10px;
  padding:8px 10px;border-radius:10px;
  text-decoration:none;transition:background .15s;
  margin-bottom:4px;
}
.online-member:hover{background:#111}
.online-avatar-wrap{position:relative;flex-shrink:0}
.online-avatar{
  width:36px;height:36px;border-radius:50%;
  object-fit:cover;background:#1a1a1a;
  display:flex;align-items:center;justify-content:center;
  font-size:1rem;color:#444;overflow:hidden;
  border:1px solid #222;
}
.online-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.online-dot{
  position:absolute;bottom:0;right:0;
  width:10px;height:10px;border-radius:50%;
  background:#22c55e;border:2px solid #0A0A0A;
}
.online-info{flex:1;min-width:0}
.online-name{font-size:0.82rem;font-weight:600;color:#fff;
             white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.online-city{font-size:0.7rem;color:#555}
.online-empty{color:#333;font-size:0.82rem;text-align:center;padding:20px 0}

/* ── Top bar mobile ── */
.topbar-mobile{
  display:none;position:sticky;top:0;z-index:200;
  background:#0A0A0A;border-bottom:1px solid #1a1a1a;
  padding:0 16px;height:52px;
  align-items:center;justify-content:space-between;
}
.topbar-brand{font-size:1.3rem;font-weight:800;color:#C9A84C;
              letter-spacing:2px;text-decoration:none}

/* ── Bottom nav mobile ── */
.bottom-nav{
  display:none;position:fixed;bottom:0;left:0;right:0;
  z-index:300;background:#0A0A0A;border-top:1px solid #1a1a1a;
  height:56px;align-items:center;justify-content:space-around;
  padding-bottom:env(safe-area-inset-bottom);
}
.bnav-btn{
  flex:1;display:flex;flex-direction:column;align-items:center;
  justify-content:center;background:none;border:none;
  color:#555;font-size:1.3rem;gap:2px;text-decoration:none;
  padding:6px 0;transition:color .15s;
}
.bnav-btn.active,.bnav-btn:hover{color:#fff}
.bnav-btn span{font-size:0.55rem;letter-spacing:.03em;color:inherit}
.bnav-post{
  width:40px;height:40px;border-radius:12px;
  background:#7B2EFF;display:flex;align-items:center;
  justify-content:center;font-size:1.3rem;color:#fff;
  border:none;cursor:pointer;flex:none;
  box-shadow:0 0 14px rgba(123,46,255,.4);text-decoration:none;
}

/* ── Utilitários ── */
.alert{padding:12px 16px;border-radius:10px;font-size:0.875rem;margin:16px}
.alert.ok{background:#1a3a1f;color:#69db7c;border:1px solid #2f6e3b}
.alert.error{background:#3a1a1a;color:#ff6b6b;border:1px solid #7e2a2a}
.btn-primary{
  display:inline-flex;align-items:center;gap:6px;
  padding:10px 20px;background:#7B2EFF;color:#fff;
  border:none;border-radius:10px;font-size:0.875rem;
  font-weight:600;cursor:pointer;text-decoration:none;
  transition:box-shadow .2s;
}
.btn-primary:hover{box-shadow:0 0 20px rgba(123,46,255,.45)}
.btn-ghost{
  display:inline-flex;align-items:center;gap:6px;
  padding:10px 20px;background:#111;color:#aaa;
  border:1px solid #222;border-radius:10px;font-size:0.875rem;
  font-weight:600;cursor:pointer;text-decoration:none;
  transition:all .15s;
}
.btn-ghost:hover{color:#fff;border-color:#333}

/* ── Responsive ── */
@media(max-width:1024px){
  .sidebar-right{display:none}
}
@media(max-width:768px){
  .sidebar-left{display:none}
  .topbar-mobile{display:flex}
  .bottom-nav{display:flex}
  body{padding-bottom:56px}
}
</style>
</head>
<body>

<!-- Top bar mobile -->
<div class="topbar-mobile">
  <a class="topbar-brand" href="/features/feed/index.php">Club61</a>
  <a href="/features/profile/index.php" style="color:#aaa;text-decoration:none;font-size:1.3rem">👤</a>
</div>

<div class="app-layout">

<!-- Sidebar esquerda -->
<nav class="sidebar-left">
  <a class="sidebar-brand" href="/features/feed/index.php">Club61</a>

  <a class="nav-item <?= ($activePage??'') === 'feed'    ? 'active' : '' ?>" href="/features/feed/index.php">
    <span class="icon">🏠</span> Feed
  </a>
  <a class="nav-item <?= ($activePage??'') === 'chat'    ? 'active' : '' ?>" href="/features/chat/index.php">
    <span class="icon">💬</span> Chat
  </a>
  <a class="nav-item <?= ($activePage??'') === 'profile' ? 'active' : '' ?>" href="/features/profile/index.php">
    <span class="icon">👤</span> Perfil
  </a>
  <a class="nav-item <?= ($activePage??'') === 'story'   ? 'active' : '' ?>" href="/features/stories/upload.php">
    <span class="icon">📷</span> Story
  </a>
  <?php if (c61_is_admin()): ?>
  <a class="nav-item <?= ($activePage??'') === 'admin'   ? 'active' : '' ?>" href="/features/admin/index.php">
    <span class="icon">⚙️</span> Admin
  </a>
  <?php endif; ?>

  <div class="nav-bottom">
    <a class="nav-item danger" href="/features/auth/logout.php">
      <span class="icon">🚪</span> Sair
    </a>
  </div>
</nav>

<!-- Conteúdo principal -->
<main class="main-content">

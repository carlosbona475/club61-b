<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: /features/feed/index.php'); exit; }

$uid     = c61_uid();
$postId  = (int)($_POST['post_id'] ?? 0);
$action  = $_POST['action'] ?? 'like';
$return  = $_POST['return_to'] ?? '/features/feed/index.php';

if ($postId > 0) {
    if ($action === 'unlike') {
        sb_delete('/rest/v1/likes?user_id=eq.' . urlencode($uid) . '&post_id=eq.' . $postId);
    } else {
        sb_post('/rest/v1/likes', ['user_id' => $uid, 'post_id' => $postId]);
    }
}
header('Location: ' . $return);
exit;

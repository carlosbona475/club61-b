<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: /features/feed/index.php'); exit; }

$uid  = c61_uid();
$file = $_FILES['image'] ?? null;

if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
    header('Location: /features/feed/index.php?status=error&message=' . urlencode('Envie uma imagem válida.'));
    exit;
}

$allowed  = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
$mime     = mime_content_type($file['tmp_name']);
if (!isset($allowed[$mime])) {
    header('Location: /features/feed/index.php?status=error&message=' . urlencode('Formato não permitido.'));
    exit;
}
if ($file['size'] > 8 * 1024 * 1024) {
    header('Location: /features/feed/index.php?status=error&message=' . urlencode('Imagem muito grande (máx 8MB).'));
    exit;
}

$filename = 'post_' . $uid . '_' . uniqid() . '.' . $allowed[$mime];
$binary   = file_get_contents($file['tmp_name']);
$code     = sb_upload('posts', $filename, $binary, $mime);

if ($code < 200 || $code >= 300) {
    header('Location: /features/feed/index.php?status=error&message=' . urlencode('Erro ao enviar imagem.'));
    exit;
}

$caption  = trim($_POST['caption'] ?? '');
$imageUrl = sb_public_url('posts', $filename);
$res      = sb_post('/rest/v1/posts', [
    'user_id'   => $uid,
    'image_url' => $imageUrl,
    'caption'   => $caption !== '' ? $caption : null,
]);

if ($res >= 200 && $res < 300) {
    header('Location: /features/feed/index.php?status=ok&message=' . urlencode('Post publicado!'));
} else {
    header('Location: /features/feed/index.php?status=error&message=' . urlencode('Erro ao salvar post. HTTP ' . $res));
}
exit;

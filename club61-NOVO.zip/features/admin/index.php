<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_admin();

$pageTitle  = 'Admin';
$activePage = 'admin';
$uid        = c61_uid();
$msg = ''; $msgType = 'ok';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'gen_invite') {
        $code = strtoupper(bin2hex(random_bytes(5)));
        $res  = sb_post('/rest/v1/invites', ['code' => $code, 'created_by' => $uid, 'status' => 'available']);
        $msg  = $res >= 200 && $res < 300 ? 'Convite gerado: ' . $code : 'Erro ao gerar convite.';
        if ($res >= 300) $msgType = 'error';
    } elseif ($action === 'revoke_invite') {
        sb_patch('/rest/v1/invites?code=eq.' . urlencode($_POST['code'] ?? ''), ['status' => 'revoked']);
        $msg = 'Convite revogado.';
    } elseif ($action === 'set_role') {
        $ruid = trim($_POST['uid'] ?? '');
        $role = trim($_POST['role'] ?? '');
        if ($ruid !== '' && $ruid !== $uid && in_array($role, ['admin','member'], true)) {
            sb_patch('/rest/v1/profiles?id=eq.' . urlencode($ruid), ['role' => $role]);
            $msg = 'Role atualizado.';
        }
    } elseif ($action === 'remove_member') {
        $ruid = trim($_POST['uid'] ?? '');
        if ($ruid !== '' && $ruid !== $uid) {
            sb_delete('/rest/v1/profiles?id=eq.' . urlencode($ruid));
            $msg = 'Membro removido.';
        }
    } elseif ($action === 'delete_post') {
        sb_delete('/rest/v1/posts?id=eq.' . (int)($_POST['pid'] ?? 0));
        $msg = 'Post removido.';
    } elseif ($action === 'delete_msg') {
        sb_delete('/rest/v1/general_messages?id=eq.' . (int)($_POST['mid'] ?? 0));
        $msg = 'Mensagem removida.';
    }
    header('Location: /features/admin/index.php?msg=' . urlencode($msg) . '&type=' . $msgType);
    exit;
}

if (isset($_GET['msg'])) { $msg = (string)$_GET['msg']; $msgType = (string)($_GET['type'] ?? 'ok'); }

$members  = sb_get('/rest/v1/profiles?select=id,display_id,username,avatar_url,role,tipo,cidade,created_at&order=created_at.asc&limit=200');
$invites  = sb_get('/rest/v1/invites?select=id,code,status,created_at&order=created_at.desc&limit=50');
$posts    = sb_get('/rest/v1/posts?select=id,user_id,image_url,caption,created_at&order=created_at.desc&limit=20');
$msgs     = sb_get('/rest/v1/general_messages?select=id,user_id,content,created_at&order=created_at.desc&limit=20');

$memberMap = [];
foreach ($members as $m) { if (isset($m['id'])) $memberMap[$m['id']] = $m; }

$totalMembers = count($members);
$totalInvites = count(array_filter($invites, fn($i) => ($i['status'] ?? '') === 'available'));
$totalAdmins  = count(array_filter($members, fn($m) => ($m['role'] ?? '') === 'admin'));

require ROOT . '/config/layout_top.php';
?>
<style>
.admin-wrap{max-width:900px;margin:0 auto;padding:24px 20px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:28px}
@media(max-width:600px){.stats{grid-template-columns:repeat(2,1fr)}}
.stat-card{background:#111;border:1px solid #1e1e1e;border-radius:12px;padding:18px;text-align:center}
.stat-num{font-size:2rem;font-weight:800;color:#C9A84C}
.stat-lbl{font-size:.7rem;color:#555;margin-top:4px;text-transform:uppercase;letter-spacing:.04em}
.tabs{display:flex;gap:4px;background:#111;border-radius:12px;padding:4px;margin-bottom:24px;border:1px solid #1a1a1a}
.tab-btn{flex:1;padding:9px;border:none;border-radius:9px;background:none;color:#555;
         font-size:.8rem;font-weight:600;cursor:pointer;transition:all .15s;letter-spacing:.02em}
.tab-btn.active{background:#1e1e1e;color:#fff}
.tab-content{display:none}
.tab-content.active{display:block}
.invite-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px}
.invite-card{background:#111;border:1px solid #1e1e1e;border-radius:12px;padding:16px;display:flex;flex-direction:column;gap:10px}
.invite-code{font-family:'Courier New',monospace;font-size:1rem;font-weight:700;color:#C9A84C;
             background:#0d0d0d;border:1px solid #1e1e1e;border-radius:8px;padding:10px;
             text-align:center;cursor:pointer;user-select:all;letter-spacing:.1em}
.invite-code:hover{border-color:#7B2EFF}
.invite-status{font-size:.72rem;text-align:center}
.status-available{color:#69db7c}.status-used{color:#555}.status-revoked{color:#ff6b6b}
.table-wrap{overflow-x:auto;border-radius:12px;border:1px solid #1a1a1a}
table{width:100%;border-collapse:collapse;font-size:.85rem}
th{background:#111;color:#555;font-size:.68rem;font-weight:600;letter-spacing:.06em;text-transform:uppercase;padding:10px 14px;text-align:left;border-bottom:1px solid #1a1a1a}
td{padding:10px 14px;border-bottom:1px solid #0f0f0f;vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:#0d0d0d}
.m-cell{display:flex;align-items:center;gap:10px}
.m-av{width:30px;height:30px;border-radius:50%;overflow:hidden;background:#1a1a1a;display:flex;align-items:center;justify-content:center;font-size:.85rem;color:#444;flex-shrink:0;border:1px solid #222}
.m-av img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.role-admin{background:rgba(201,168,76,.15);color:#C9A84C;border:1px solid rgba(201,168,76,.3);border-radius:6px;padding:2px 8px;font-size:.68rem;font-weight:700}
.role-member{background:#1a1a1a;color:#555;border:1px solid #222;border-radius:6px;padding:2px 8px;font-size:.68rem;font-weight:700}
.btn-sm{padding:5px 10px;border-radius:7px;border:none;font-size:.75rem;font-weight:600;cursor:pointer}
.btn-danger{background:rgba(255,107,107,.12);color:#ff6b6b;border:1px solid rgba(255,107,107,.3)}
.btn-ghost-sm{background:#1a1a1a;color:#aaa;border:1px solid #222}
.post-thumb{width:44px;height:44px;border-radius:6px;object-fit:cover;background:#1a1a1a;border:1px solid #222}
.section-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}
.section-lbl{font-size:.8rem;font-weight:700;color:#C9A84C;letter-spacing:.06em;text-transform:uppercase}
</style>

<div class="admin-wrap">
  <?php if ($msg !== ''): ?>
    <div class="alert <?= $msgType ?>"><?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?></div>
  <?php endif; ?>

  <div class="stats">
    <div class="stat-card"><div class="stat-num"><?= $totalMembers ?></div><div class="stat-lbl">Membros</div></div>
    <div class="stat-card"><div class="stat-num"><?= $totalInvites ?></div><div class="stat-lbl">Convites ativos</div></div>
    <div class="stat-card"><div class="stat-num"><?= count($posts) ?></div><div class="stat-lbl">Posts</div></div>
    <div class="stat-card"><div class="stat-num"><?= $totalAdmins ?></div><div class="stat-lbl">Admins</div></div>
  </div>

  <div class="tabs">
    <button class="tab-btn active" onclick="switchTab('convites',this)">🎟️ Convites</button>
    <button class="tab-btn" onclick="switchTab('membros',this)">👥 Membros</button>
    <button class="tab-btn" onclick="switchTab('posts',this)">🖼️ Posts</button>
    <button class="tab-btn" onclick="switchTab('chat',this)">💬 Chat</button>
  </div>

  <!-- Convites -->
  <div class="tab-content active" id="tab-convites">
    <div class="section-header">
      <span class="section-lbl">Convites</span>
      <form method="POST" style="display:inline">
        <input type="hidden" name="action" value="gen_invite">
        <button class="btn-primary" type="submit">＋ Gerar convite</button>
      </form>
    </div>
    <div class="invite-grid">
      <?php foreach ($invites as $inv):
        $icode   = $inv['code']   ?? '';
        $istatus = $inv['status'] ?? 'unknown';
      ?>
      <div class="invite-card">
        <div class="invite-code" onclick="copyCode('<?= htmlspecialchars($icode, ENT_QUOTES, 'UTF-8') ?>',this)"><?= htmlspecialchars($icode, ENT_QUOTES, 'UTF-8') ?></div>
        <div style="font-size:.65rem;color:#333;text-align:center">clique para copiar</div>
        <div class="invite-status status-<?= $istatus ?>">
          <?= match($istatus){ 'available'=>'✅ Disponível','used'=>'✔ Utilizado','revoked'=>'✕ Revogado',default=>$istatus } ?>
        </div>
        <?php if ($istatus === 'available'): ?>
          <form method="POST">
            <input type="hidden" name="action" value="revoke_invite">
            <input type="hidden" name="code" value="<?= htmlspecialchars($icode, ENT_QUOTES, 'UTF-8') ?>">
            <button class="btn-sm btn-danger" type="submit" style="width:100%">Revogar</button>
          </form>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Membros -->
  <div class="tab-content" id="tab-membros">
    <div class="table-wrap">
      <table>
        <thead><tr><th>Membro</th><th>Tipo/Cidade</th><th>Role</th><th>Ações</th></tr></thead>
        <tbody>
          <?php foreach ($members as $m):
            $muid   = (string)($m['id'] ?? '');
            $mlabel = c61_cl_label($m);
            $mav    = trim((string)($m['avatar_url'] ?? ''));
            $mrole  = $m['role'] ?? 'member';
            $isMe   = $muid === $uid;
          ?>
          <tr>
            <td><div class="m-cell"><div class="m-av"><?php if ($mav !== ''): ?><img src="<?= htmlspecialchars($mav, ENT_QUOTES, 'UTF-8') ?>" alt=""><?php else: ?>👤<?php endif; ?></div><div><div style="font-size:.875rem;font-weight:600;color:#fff"><?= htmlspecialchars($mlabel, ENT_QUOTES, 'UTF-8') ?></div><div style="font-size:.7rem;color:#555"><?= htmlspecialchars($m['username'] ?? '', ENT_QUOTES, 'UTF-8') ?></div></div></div></td>
            <td><div style="color:#aaa;font-size:.78rem"><?= htmlspecialchars($m['tipo'] ?? '', ENT_QUOTES, 'UTF-8') ?></div><div style="color:#555;font-size:.72rem"><?= htmlspecialchars($m['cidade'] ?? '', ENT_QUOTES, 'UTF-8') ?></div></td>
            <td><span class="<?= $mrole === 'admin' ? 'role-admin' : 'role-member' ?>"><?= $mrole === 'admin' ? '★ Admin' : 'Membro' ?></span></td>
            <td>
              <?php if (!$isMe): ?>
              <div style="display:flex;gap:6px;flex-wrap:wrap">
                <form method="POST" style="display:inline"><input type="hidden" name="action" value="set_role"><input type="hidden" name="uid" value="<?= htmlspecialchars($muid, ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="role" value="<?= $mrole === 'admin' ? 'member' : 'admin' ?>"><button class="btn-sm btn-ghost-sm" type="submit"><?= $mrole === 'admin' ? '↓ Rebaixar' : '↑ Promover' ?></button></form>
                <form method="POST" style="display:inline" onsubmit="return confirm('Remover membro?')"><input type="hidden" name="action" value="remove_member"><input type="hidden" name="uid" value="<?= htmlspecialchars($muid, ENT_QUOTES, 'UTF-8') ?>"><button class="btn-sm btn-danger" type="submit">✕</button></form>
              </div>
              <?php else: ?><span style="color:#333;font-size:.75rem">você</span><?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Posts -->
  <div class="tab-content" id="tab-posts">
    <div class="table-wrap">
      <table>
        <thead><tr><th>Img</th><th>Autor</th><th>Legenda</th><th>Ação</th></tr></thead>
        <tbody>
          <?php foreach ($posts as $p):
            $pid    = (string)($p['id']       ?? '');
            $pUid   = (string)($p['user_id']  ?? '');
            $pImg   = trim((string)($p['image_url'] ?? ''));
            $pCap   = trim((string)($p['caption']   ?? ''));
            $author = $memberMap[$pUid] ?? [];
            $aLabel = c61_cl_label($author, substr($pUid,0,8).'…');
          ?>
          <tr>
            <td><?php if ($pImg !== ''): ?><img class="post-thumb" src="<?= htmlspecialchars($pImg, ENT_QUOTES, 'UTF-8') ?>" alt=""><?php else: ?>—<?php endif; ?></td>
            <td style="color:#aaa;font-size:.78rem"><?= htmlspecialchars($aLabel, ENT_QUOTES, 'UTF-8') ?></td>
            <td style="color:#ccc;font-size:.82rem;max-width:200px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($pCap ?: '—', ENT_QUOTES, 'UTF-8') ?></td>
            <td><form method="POST" style="display:inline" onsubmit="return confirm('Remover post?')"><input type="hidden" name="action" value="delete_post"><input type="hidden" name="pid" value="<?= htmlspecialchars($pid, ENT_QUOTES, 'UTF-8') ?>"><button class="btn-sm btn-danger" type="submit">✕</button></form></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Chat -->
  <div class="tab-content" id="tab-chat">
    <div class="table-wrap">
      <table>
        <thead><tr><th>Autor</th><th>Mensagem</th><th>Ação</th></tr></thead>
        <tbody>
          <?php foreach ($msgs as $cm):
            $mid    = (string)($cm['id']      ?? '');
            $cmUid  = (string)($cm['user_id'] ?? '');
            $cmText = trim((string)($cm['content']   ?? ''));
            $author = $memberMap[$cmUid] ?? [];
            $cLabel = c61_cl_label($author, substr($cmUid,0,8).'…');
          ?>
          <tr>
            <td style="color:#aaa;font-size:.78rem;white-space:nowrap"><?= htmlspecialchars($cLabel, ENT_QUOTES, 'UTF-8') ?></td>
            <td style="color:#ccc;font-size:.82rem;max-width:300px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($cmText, ENT_QUOTES, 'UTF-8') ?></td>
            <td><form method="POST" style="display:inline" onsubmit="return confirm('Remover mensagem?')"><input type="hidden" name="action" value="delete_msg"><input type="hidden" name="mid" value="<?= htmlspecialchars($mid, ENT_QUOTES, 'UTF-8') ?>"><button class="btn-sm btn-danger" type="submit">✕</button></form></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
function switchTab(name, btn) {
  document.querySelectorAll('.tab-content').forEach(function(el){ el.classList.remove('active'); });
  document.querySelectorAll('.tab-btn').forEach(function(el){ el.classList.remove('active'); });
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}
function copyCode(code, el) {
  navigator.clipboard.writeText(code).then(function(){
    var orig = el.textContent;
    el.textContent = '✓ Copiado!';
    el.style.color = '#69db7c';
    setTimeout(function(){ el.textContent = orig; el.style.color = ''; }, 1500);
  });
}
</script>

<?php require ROOT . '/config/layout_bottom.php'; ?>

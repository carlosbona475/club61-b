<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_session();

if (c61_logged_in()) {
    header('Location: /features/feed/index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email']    ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($email === '' || $password === '') {
        $error = 'Informe email e senha.';
    } else {
        $ch = curl_init(SUPABASE_URL . '/auth/v1/token?grant_type=password');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_POSTFIELDS     => json_encode(['email' => $email, 'password' => $password]),
            CURLOPT_HTTPHEADER     => [
                'apikey: '         . SUPABASE_ANON_KEY,
                'Content-Type: application/json',
            ],
        ]);
        $raw  = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($raw, true);

        if ($code === 200 && isset($data['access_token'])) {
            $_SESSION['access_token'] = $data['access_token'];
            $_SESSION['user_id']      = $data['user']['id'];
            $_SESSION['user_email']   = $email;

            // Garantir perfil existe
            $profile = c61_get_profile($_SESSION['user_id']);
            if (empty($profile)) {
                $count = count(sb_get('/rest/v1/profiles?select=id'));
                sb_post('/rest/v1/profiles', [
                    'id'         => $_SESSION['user_id'],
                    'username'   => explode('@', $email)[0],
                    'role'       => $count === 0 ? 'admin' : 'member',
                    'display_id' => 'CL' . str_pad((string)($count + 1), 2, '0', STR_PAD_LEFT),
                    'status'     => 'active',
                ]);
            }

            header('Location: /features/feed/index.php');
            exit;
        } else {
            $error = 'Email ou senha incorretos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — Club61</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{background:#0A0A0A;color:#fff;font-family:'Segoe UI',system-ui,sans-serif;
     min-height:100vh;display:flex;align-items:center;justify-content:center;
     padding:24px 16px;-webkit-font-smoothing:antialiased}
.card{width:100%;max-width:420px;background:#111;border:1px solid #1e1e1e;
      border-radius:16px;padding:40px 32px}
h1{font-size:2rem;font-weight:800;color:#C9A84C;letter-spacing:3px;
   text-align:center;margin-bottom:6px}
.sub{color:#555;font-size:0.82rem;text-align:center;margin-bottom:28px}
.error{background:#3a1a1a;color:#ff6b6b;border:1px solid #7e2a2a;
       border-radius:8px;padding:12px 14px;font-size:0.85rem;margin-bottom:20px}
label{display:block;font-size:0.72rem;font-weight:600;color:#555;
      letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px}
.field{margin-bottom:18px}
input[type=email],input[type=password]{
  width:100%;background:#1a1a1a;border:1px solid #2a2a2a;border-radius:10px;
  color:#fff;padding:12px 14px;font-size:0.95rem;outline:none;
  transition:border-color .15s;font-family:inherit}
input:focus{border-color:#7B2EFF}
input::placeholder{color:#333}
.btn{width:100%;padding:14px;background:#7B2EFF;color:#fff;border:none;
     border-radius:10px;font-size:1rem;font-weight:700;cursor:pointer;
     transition:box-shadow .25s;margin-top:8px}
.btn:hover{box-shadow:0 0 24px rgba(123,46,255,.5)}
.foot{margin-top:24px;text-align:center;font-size:0.875rem}
.foot a{color:#555;text-decoration:none;transition:color .15s}
.foot a:hover{color:#C9A84C}
</style>
</head>
<body>
<div class="card">
  <h1>Club61</h1>
  <p class="sub">Acesso exclusivo para membros</p>
  <?php if ($error): ?>
    <div class="error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
  <?php endif; ?>
  <form method="POST">
    <div class="field">
      <label>E-mail</label>
      <input type="email" name="email" placeholder="seu@email.com" required autocomplete="email">
    </div>
    <div class="field">
      <label>Senha</label>
      <input type="password" name="password" placeholder="••••••••" required autocomplete="current-password">
    </div>
    <button class="btn" type="submit">Entrar</button>
  </form>
  <p class="foot"><a href="/features/auth/register.php">Não tem conta? Cadastre-se com convite</a></p>
</div>
</body>
</html>

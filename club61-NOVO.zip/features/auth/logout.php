<?php
session_start();
$_SESSION = [];
session_destroy();
header('Location: /features/auth/login.php');
exit;

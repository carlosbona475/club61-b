<?php
require_once __DIR__ . '/../../auth_guard.php';
require_once __DIR__ . '/../../config/layout.php';

$uid   = (string)$_SESSION['user_id'];
$token = (string)$_SESSION['access_token'];
$status  = $_GET['status']  ?? '';
$message = $_GET['message'] ?? '';

// ── Stories ───────────────────────────────────────────────────────────────────
$storyProfiles = [];
$nowIso = gmdate('Y-m-d\TH:i:s\Z');
$stRows = sb_get('/rest/v1/stories?select=user_id,expires_at&expires_at=gt.' . rawurlencode($nowIso) . '&order=created_at.desc&limit=100');
if ($stRows) {
    $seen = []; $uids = [];
    foreach ($stRows as $sr) {
        $id = (string)($sr['user_id'] ?? '');
        if ($id && !isset($seen[$id])) { $seen[$id] = true; $uids[] = $id; }
        if (count($uids) >= 20) break;
    }
    if ($uids) {
        $profs = sb_get('/rest/v1/profiles?select=id,display_id,username,avatar_url&id=in.(' . implode(',', $uids) . ')');
        if ($profs) {
            $byId = [];
            foreach ($profs as $p) $byId[$p['id']] = $p;
            foreach ($uids as $id) if (isset($byId[$id])) $storyProfiles[] = $byId[$id];
        }
    }
}

// ── Posts ─────────────────────────────────────────────────────────────────────
$page   = max(1, (int)($_GET['page'] ?? 1));
$limit  = 10;
$offset = ($page - 1) * $limit;
$posts  = sb_get('/rest/v1/posts?select=id,user_id,image_url,caption,created_at&order=created_at.desc&limit='.$limit.'&offset='.$offset) ?? [];

// Autores
$authorMap = [];
$authorIds = array_unique(array_filter(array_column($posts, 'user_id')));
if ($authorIds) {
    $rows = sb_get('/rest/v1/profiles?select=id,display_id,username,avatar_url,last_seen&id=in.(' . implode(',', $authorIds) . ')');
    if ($rows) foreach ($rows as $r) $authorMap[$r['id']] = $r;
}

// Likes do usuário atual
$myLikes = [];
$lkRows  = sb_get('/rest/v1/post_likes?select=post_id&user_id=eq.' . urlencode($uid));
if ($lkRows) foreach ($lkRows as $l) $myLikes[(int)$l['post_id']] = true;

// Contagem de likes
$postIds = array_filter(array_column($posts, 'id'));
$likesMap = [];
if ($postIds) {
    $lRows = sb_get('/rest/v1/post_likes?select=post_id&post_id=in.(' . implode(',', $postIds) . ')');
    if ($lRows) foreach ($lRows as $l) $likesMap[(int)$l['post_id']] = ($likesMap[(int)$l['post_id']] ?? 0) + 1;
}

// Comentários recentes
$commMap = [];
if ($postIds) {
    $cRows = sb_get('/rest/v1/post_comments?select=id,post_id,user_id,comment_text&post_id=in.(' . implode(',', $postIds) . ')&order=created_at.desc&limit=60');
    if ($cRows) {
        $cuids = array_unique(array_filter(array_column($cRows, 'user_id')));
        $cpMap = [];
        if ($cuids) {
            $cpRows = sb_get('/rest/v1/profiles?select=id,display_id,username&id=in.(' . implode(',', $cuids) . ')');
            if ($cpRows) foreach ($cpRows as $cp) $cpMap[$cp['id']] = $cp;
        }
        foreach ($cRows as $c) {
            $pid = (int)$c['post_id'];
            if (count($commMap[$pid] ?? []) < 3) {
                $c['_author'] = $cpMap[$c['user_id']] ?? null;
                $commMap[$pid][] = $c;
            }
        }
    }
}

$isAdmin  = is_admin($uid);
$members  = count_members();
$onlineUsers = get_online_users();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Feed — Club61</title>
<?php render_css() ?>
<style>
.feed-wrap{display:flex;max-width:1100px;margin:0 auto;padding:0 16px 32px;gap:28px}
.feed-center{flex:1;min-width:0;max-width:520px}
.feed-right{width:240px;flex-shrink:0;padding-top:16px}
@media(max-width:900px){.feed-right{display:none}}
@media(max-width:600px){.feed-wrap{padding:0 0 80px}}
.members-bar{font-size:.75rem;color:var(--dim);padding:10px 16px;text-align:right}
</style>
</head>
<body>
<?php render_topnav('feed') ?>

<!-- Stories -->
<div class="stories-bar">
  <div class="stories-scroll">
    <div class="story-item">
      <a class="story-ring story-ring--add" href="/features/profile/upload_story.php">
        <div class="story-inner"><span style="font-size:1.8rem;color:var(--purple)">+</span></div>
      </a>
      <span class="story-label">Meu story</span>
    </div>
    <?php foreach ($storyProfiles as $sp):
      $sid    = (string)($sp['id'] ?? '');
      $slabel = cl_label($sp);
      $savatar = trim((string)($sp['avatar_url'] ?? ''));
      if (!$sid) continue;
    ?>
    <div class="story-item">
      <a class="story-ring" href="/features/stories/view.php?id=<?= urlencode($sid) ?>">
        <div class="story-inner">
          <?php if ($savatar): ?><img src="<?= htmlspecialchars($savatar) ?>" alt="">
          <?php else: ?><span>👤</span><?php endif; ?>
        </div>
      </a>
      <span class="story-label"><?= htmlspecialchars($slabel) ?></span>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="members-bar"><?= $members ?> membros</div>

<?php if ($status === 'ok'): ?>
  <div style="max-width:520px;margin:8px auto 0;padding:0 16px">
    <div class="alert alert-ok"><?= htmlspecialchars($message ?: 'OK') ?></div>
  </div>
<?php elseif ($status === 'error'): ?>
  <div style="max-width:520px;margin:8px auto 0;padding:0 16px">
    <div class="alert alert-error"><?= htmlspecialchars($message ?: 'Erro') ?></div>
  </div>
<?php endif; ?>

<div class="feed-wrap">
  <div class="feed-center">

    <!-- Novo post -->
    <div class="card" style="padding:16px;margin-bottom:20px">
      <form action="/features/feed/create_post.php" method="POST" enctype="multipart/form-data">
        <input type="file" id="pFile" name="image" accept="image/*,video/mp4" style="display:none" required>
        <div id="pZone" onclick="document.getElementById('pFile').click()"
             style="background:#0d0d0d;border:2px dashed #222;border-radius:10px;
                    padding:28px;text-align:center;color:var(--dim);cursor:pointer;
                    margin-bottom:12px;transition:border-color .2s">
          📷 Toque para escolher foto ou vídeo
        </div>
        <img id="pPreview" src="" style="display:none;width:100%;max-height:280px;object-fit:cover;border-radius:10px;margin-bottom:12px">
        <div class="field" style="margin-bottom:10px">
          <input type="text" name="caption" placeholder="Escreva uma legenda...">
        </div>
        <button class="btn btn-primary btn-full" type="submit">Publicar</button>
      </form>
    </div>

    <!-- Posts -->
    <div id="postsFeed">
    <?php foreach ($posts as $post):
      $pid     = (int)($post['id']        ?? 0);
      $pUid    = (string)($post['user_id']   ?? '');
      $pImg    = trim((string)($post['image_url'] ?? ''));
      $pCap    = trim((string)($post['caption']   ?? ''));
      $pTime   = (string)($post['created_at'] ?? '');
      $author  = $authorMap[$pUid] ?? [];
      $aLabel  = $author ? cl_label($author) : 'Membro';
      $aAvatar = trim((string)($author['avatar_url'] ?? ''));
      $aOnline = is_online($author['last_seen'] ?? null);
      $liked   = isset($myLikes[$pid]);
      $nlikes  = $likesMap[$pid] ?? 0;
      $timeAgo = $pTime ? time_ago($pTime) : '';
      $comms   = $commMap[$pid] ?? [];
    ?>
    <div class="card post-block" style="margin-bottom:20px">
      <div class="post-header">
        <a class="post-avatar" href="/features/profile/view.php?id=<?= urlencode($pUid) ?>" style="position:relative">
          <?php if ($aAvatar): ?><img src="<?= htmlspecialchars($aAvatar) ?>" alt="">
          <?php else: ?>👤<?php endif; ?>
          <?php if ($aOnline): ?>
            <span style="position:absolute;bottom:0;right:0;width:10px;height:10px;background:#22c55e;border-radius:50%;border:2px solid var(--card)"></span>
          <?php endif; ?>
        </a>
        <a class="post-author" href="/features/profile/view.php?id=<?= urlencode($pUid) ?>">
          <div class="post-author-name"><?= htmlspecialchars($aLabel) ?></div>
          <?php if ($timeAgo): ?><div class="post-author-time"><?= htmlspecialchars($timeAgo) ?></div><?php endif; ?>
        </a>
        <?php if ($pUid === $uid || $isAdmin): ?>
          <form action="/features/feed/delete_post.php" method="POST"
                onsubmit="return confirm('Excluir este post?')" style="margin-left:auto">
            <input type="hidden" name="post_id" value="<?= $pid ?>">
            <button class="btn btn-danger btn-sm" type="submit">✕</button>
          </form>
        <?php endif; ?>
      </div>
      <?php if ($pImg): ?>
        <img class="post-img" src="<?= htmlspecialchars($pImg) ?>" alt="Post" loading="lazy">
      <?php endif; ?>
      <div class="post-actions">
        <form action="/features/feed/toggle_like.php" method="POST" style="display:inline">
          <input type="hidden" name="post_id" value="<?= $pid ?>">
          <input type="hidden" name="return_to" value="/features/feed/index.php">
          <button class="like-btn <?= $liked ? 'liked' : '' ?>" type="submit">
            <?= $liked ? '♥' : '♡' ?>
          </button>
        </form>
        <?php if ($nlikes > 0): ?>
          <span style="font-size:.85rem;color:var(--muted);margin-left:2px"><?= $nlikes ?></span>
        <?php endif; ?>
      </div>
      <?php if ($pCap): ?>
        <div class="post-caption"><strong><?= htmlspecialchars($aLabel) ?></strong><?= htmlspecialchars($pCap) ?></div>
      <?php endif; ?>
      <div class="post-comments">
        <?php foreach (array_reverse($comms) as $c): ?>
          <?php $ca = $c['_author'] ?? null; $cLabel = $ca ? cl_label($ca) : 'Membro'; ?>
          <div class="comment-line"><strong><?= htmlspecialchars($cLabel) ?></strong><?= htmlspecialchars((string)($c['comment_text'] ?? '')) ?></div>
        <?php endforeach; ?>
        <?php if (count($comms) >= 3): ?>
          <a href="/features/feed/post.php?id=<?= $pid ?>" style="color:var(--dim);font-size:.78rem;text-decoration:none;display:block;margin-bottom:6px">Ver todos os comentários</a>
        <?php endif; ?>
        <form action="/features/feed/add_comment.php" method="POST" class="comment-form">
          <input type="hidden" name="post_id" value="<?= $pid ?>">
          <input type="hidden" name="return_to" value="/features/feed/index.php">
          <input class="comment-input" type="text" name="content" placeholder="Comentar...">
          <button class="comment-submit" type="submit">Publicar</button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($posts)): ?>
      <div style="text-align:center;color:var(--dim);padding:48px 0">
        Nenhuma publicação ainda. Seja o primeiro!
      </div>
    <?php endif; ?>
    </div><!-- #postsFeed -->

    <?php if (count($posts) >= $limit): ?>
      <div class="feed-pager" style="text-align:center;padding:16px">
        <a class="btn btn-ghost" href="?page=<?= $page + 1 ?>">Carregar mais</a>
      </div>
    <?php endif; ?>
  </div>

  <!-- Sidebar direita: online -->
  <div class="feed-right">
    <div style="font-size:.72rem;font-weight:700;color:var(--dim);
                text-transform:uppercase;letter-spacing:.08em;margin-bottom:12px">
      🟢 Online agora
    </div>
    <?php if (empty($onlineUsers)): ?>
      <div style="color:var(--dim);font-size:.85rem">Nenhum membro online</div>
    <?php else: ?>
      <?php foreach ($onlineUsers as $ou):
        $oid    = (string)($ou['id']         ?? '');
        $olabel = cl_label($ou);
        $oav    = trim((string)($ou['avatar_url'] ?? ''));
        $ocid   = trim((string)($ou['cidade']     ?? ''));
      ?>
      <a class="sidebar-user" href="/features/profile/view.php?id=<?= urlencode($oid) ?>">
        <div class="su-avatar">
          <?php if ($oav): ?><img src="<?= htmlspecialchars($oav) ?>" alt="">
          <?php else: ?>👤<?php endif; ?>
          <span class="online-dot"></span>
        </div>
        <div class="su-info">
          <div class="su-name"><?= htmlspecialchars($olabel) ?></div>
          <?php if ($ocid): ?><div class="su-cidade"><?= htmlspecialchars($ocid) ?></div><?php endif; ?>
        </div>
      </a>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<script>
document.getElementById('pFile').addEventListener('change', function() {
  if (this.files && this.files[0]) {
    var f = this.files[0];
    if (f.type.startsWith('image/')) {
      var r = new FileReader();
      r.onload = function(e) {
        var p = document.getElementById('pPreview');
        p.src = e.target.result;
        p.style.display = 'block';
        document.getElementById('pZone').style.display = 'none';
      };
      r.readAsDataURL(f);
    } else {
      document.getElementById('pZone').textContent = '🎥 ' + f.name;
    }
  }
});

// Infinite scroll
(function(){
  var pager = document.querySelector('.feed-pager a');
  if (!pager) return;
  var loading = false, done = false;
  window.addEventListener('scroll', function(){
    if (loading || done || !pager) return;
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 400) {
      loading = true;
      fetch(pager.href.replace('index.php','load_more.php'), {credentials:'same-origin'})
        .then(function(r){ return r.text(); })
        .then(function(html){
          var t = (html||'').trim();
          if (!t) { done = true; pager.parentElement.style.display='none'; return; }
          var box = document.createElement('div');
          box.innerHTML = t;
          var cards = box.querySelectorAll('.post-block');
          var feed  = document.getElementById('postsFeed');
          if (!feed || !cards.length) { done = true; return; }
          cards.forEach(function(c){ feed.insertBefore(c, feed.querySelector('.feed-pager')); });
          var np = box.querySelector('.feed-pager a');
          if (np) pager.href = np.href; else { done = true; pager.parentElement.style.display='none'; }
        })
        .catch(function(){})
        .finally(function(){ loading = false; });
    }
  }, {passive:true});
})();
</script>
</body>
</html>

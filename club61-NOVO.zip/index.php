<?php
session_start();
if (!empty($_SESSION['access_token'])) {
    header('Location: /features/feed/index.php');
} else {
    header('Location: /features/auth/login.php');
}
exit;

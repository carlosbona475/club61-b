<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();

$pageTitle  = 'Mensagens';
$activePage = 'chat';
$uid        = c61_uid();

// Buscar todas DMs
$sent = sb_get('/rest/v1/direct_messages?sender_id=eq.' . urlencode($uid) . '&select=id,sender_id,receiver_id,content,created_at,read_at&order=created_at.desc&limit=100');
$recv = sb_get('/rest/v1/direct_messages?receiver_id=eq.' . urlencode($uid) . '&select=id,sender_id,receiver_id,content,created_at,read_at&order=created_at.desc&limit=100');
$all  = array_merge($sent, $recv);

// Montar conversas
$convos = [];
foreach ($all as $dm) {
    $otherId = (string)(($dm['sender_id'] === $uid) ? $dm['receiver_id'] : $dm['sender_id']);
    if (!isset($convos[$otherId])) {
        $convos[$otherId] = ['last_msg' => $dm['content'], 'last_time' => $dm['created_at'], 'unread' => 0];
    }
    if ($dm['receiver_id'] === $uid && empty($dm['read_at'])) {
        $convos[$otherId]['unread']++;
    }
}

// Perfis
$profiles = [];
if (!empty($convos)) {
    $pRows = sb_get('/rest/v1/profiles?select=id,display_id,username,avatar_url,last_seen&id=in.(' . implode(',', array_keys($convos)) . ')');
    foreach ($pRows as $p) { if (isset($p['id'])) $profiles[$p['id']] = $p; }
}

// Todos os membros para nova DM
$allMembers = sb_get('/rest/v1/profiles?select=id,display_id,username,avatar_url&order=display_id.asc&limit=100');
$allMembers = array_filter($allMembers, fn($m) => ($m['id'] ?? '') !== $uid);

require ROOT . '/config/layout_top.php';
?>
<style>
.inbox-wrap{max-width:600px;margin:0 auto}
.inbox-header{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid #141414}
.inbox-title{font-size:1rem;font-weight:700;color:#fff}
.btn-new-dm{background:none;border:none;color:#7B2EFF;font-size:1.3rem;cursor:pointer;padding:4px}
.tabs{display:flex;border-bottom:1px solid #141414}
.tab{flex:1;padding:12px;text-align:center;font-size:0.82rem;font-weight:600;
     color:#555;text-decoration:none;border-bottom:2px solid transparent;transition:all .15s}
.tab.active{color:#fff;border-bottom-color:#7B2EFF}
.tab:hover{color:#aaa}
.convo-item{display:flex;align-items:center;gap:12px;padding:14px 20px;
            text-decoration:none;border-bottom:1px solid #0f0f0f;transition:background .15s}
.convo-item:hover{background:#0d0d0d}
.convo-av{width:46px;height:46px;border-radius:50%;overflow:hidden;background:#1a1a1a;
           display:flex;align-items:center;justify-content:center;font-size:1.2rem;
           color:#444;flex-shrink:0;position:relative;border:1px solid #222}
.convo-av img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.convo-online{position:absolute;bottom:0;right:0;width:11px;height:11px;
              border-radius:50%;background:#22c55e;border:2px solid #0A0A0A}
.convo-info{flex:1;min-width:0}
.convo-name{font-size:0.875rem;font-weight:600;color:#fff;margin-bottom:2px}
.convo-preview{font-size:0.78rem;color:#555;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.convo-meta{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0}
.convo-time{font-size:0.68rem;color:#444}
.unread-badge{background:#7B2EFF;color:#fff;font-size:0.65rem;font-weight:700;
              border-radius:10px;padding:2px 7px;min-width:18px;text-align:center}
.empty-state{text-align:center;padding:48px 24px;color:#333}
.modal-backdrop{position:fixed;inset:0;z-index:500;background:rgba(0,0,0,.85);
                display:none;align-items:flex-end;justify-content:center;backdrop-filter:blur(4px)}
.modal-backdrop.open{display:flex}
.modal-sheet{width:100%;max-width:600px;background:#111;border-radius:20px 20px 0 0;
             padding:0 0 32px;max-height:80vh;overflow-y:auto;
             animation:sheet-up .3s cubic-bezier(.22,1,.36,1)}
@keyframes sheet-up{from{transform:translateY(100%)}to{transform:translateY(0)}}
.modal-handle{width:36px;height:4px;background:#333;border-radius:2px;margin:12px auto 0}
.modal-title{font-size:1rem;font-weight:700;color:#C9A84C;text-align:center;padding:16px;border-bottom:1px solid #1e1e1e}
</style>

<div class="inbox-wrap">
  <div class="inbox-header">
    <span class="inbox-title">Mensagens privadas</span>
    <button class="btn-new-dm" id="openNewDM" title="Nova mensagem">✏️</button>
  </div>
  <div class="tabs">
    <a class="tab" href="/features/chat/index.php">💬 Chat Geral</a>
    <a class="tab active" href="/features/chat/inbox.php">✉️ Privado</a>
  </div>

  <?php if (empty($convos)): ?>
    <div class="empty-state">
      <div style="font-size:2rem;opacity:.3;margin-bottom:12px">✉️</div>
      <div style="font-size:.875rem">Nenhuma conversa ainda.<br>Toque em ✏️ para começar.</div>
    </div>
  <?php else: ?>
    <?php foreach ($convos as $otherId => $conv):
      $p      = $profiles[$otherId] ?? [];
      $pLabel = c61_cl_label($p);
      $pAv    = trim((string)($p['avatar_url'] ?? ''));
      $pOn    = c61_is_online($p['last_seen'] ?? null);
      $ago    = c61_time_ago($conv['last_time']);
      $prev   = mb_substr($conv['last_msg'], 0, 40, 'UTF-8') . (mb_strlen($conv['last_msg'], 'UTF-8') > 40 ? '…' : '');
    ?>
    <a class="convo-item" href="/features/chat/dm.php?with=<?= urlencode($otherId) ?>">
      <div class="convo-av">
        <?php if ($pAv !== ''): ?><img src="<?= htmlspecialchars($pAv, ENT_QUOTES, 'UTF-8') ?>" alt=""><?php else: ?>👤<?php endif; ?>
        <?php if ($pOn): ?><div class="convo-online"></div><?php endif; ?>
      </div>
      <div class="convo-info">
        <div class="convo-name"><?= htmlspecialchars($pLabel, ENT_QUOTES, 'UTF-8') ?></div>
        <div class="convo-preview"><?= htmlspecialchars($prev, ENT_QUOTES, 'UTF-8') ?></div>
      </div>
      <div class="convo-meta">
        <span class="convo-time"><?= htmlspecialchars($ago, ENT_QUOTES, 'UTF-8') ?></span>
        <?php if ($conv['unread'] > 0): ?>
          <span class="unread-badge"><?= (int)$conv['unread'] ?></span>
        <?php endif; ?>
      </div>
    </a>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<!-- Modal nova DM -->
<div class="modal-backdrop" id="newDMModal">
  <div class="modal-sheet">
    <div class="modal-handle"></div>
    <div class="modal-title">Nova mensagem</div>
    <?php foreach ($allMembers as $m):
      $mId    = (string)($m['id'] ?? '');
      $mLabel = c61_cl_label($m);
      $mAv    = trim((string)($m['avatar_url'] ?? ''));
    ?>
    <a href="/features/chat/dm.php?with=<?= urlencode($mId) ?>"
       style="display:flex;align-items:center;gap:12px;padding:12px 20px;
              text-decoration:none;border-bottom:1px solid #0f0f0f;transition:background .15s"
       onmouseover="this.style.background='#151515'" onmouseout="this.style.background=''">
      <div style="width:38px;height:38px;border-radius:50%;overflow:hidden;background:#1a1a1a;
                  display:flex;align-items:center;justify-content:center;font-size:1rem;
                  color:#444;flex-shrink:0;border:1px solid #222">
        <?php if ($mAv !== ''): ?><img src="<?= htmlspecialchars($mAv, ENT_QUOTES, 'UTF-8') ?>" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%"><?php else: ?>👤<?php endif; ?>
      </div>
      <span style="font-size:.875rem;font-weight:600;color:#fff"><?= htmlspecialchars($mLabel, ENT_QUOTES, 'UTF-8') ?></span>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<script>
var modal = document.getElementById('newDMModal');
document.getElementById('openNewDM').addEventListener('click', function(){ modal.classList.add('open'); });
modal.addEventListener('click', function(e){ if (e.target === modal) modal.classList.remove('open'); });
</script>

<?php require ROOT . '/config/layout_bottom.php'; ?>

<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();

$pageTitle  = 'Perfil';
$activePage = 'profile';
$uid        = c61_uid();
$status     = (string)($_GET['status']  ?? '');
$message    = (string)($_GET['message'] ?? '');

$profile = c61_get_profile($uid);
$clLabel  = c61_cl_label($profile);
$avatar   = trim((string)($profile['avatar_url'] ?? ''));
$posts    = sb_get('/rest/v1/posts?user_id=eq.' . urlencode($uid) . '&select=id,image_url,caption,created_at&order=created_at.desc&limit=30');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'update_profile') {
        $tipo = trim($_POST['tipo'] ?? '');
        $data = [
            'bio'         => mb_substr(trim($_POST['bio'] ?? ''), 0, 500, 'UTF-8') ?: null,
            'tipo'        => $tipo,
            'cidade'      => trim($_POST['cidade']  ?? ''),
            'age'         => (int)($_POST['age']    ?? 0) ?: null,
            'partner_age' => $tipo === 'Casal' ? ((int)($_POST['partner_age'] ?? 0) ?: null) : null,
        ];
        sb_patch('/rest/v1/profiles?id=eq.' . urlencode($uid), $data);
        header('Location: /features/profile/index.php?status=ok&message=' . urlencode('Perfil atualizado!'));
        exit;
    }
    if ($action === 'upload_avatar') {
        $file = $_FILES['avatar'] ?? null;
        if ($file && $file['error'] === UPLOAD_ERR_OK) {
            $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            $mime    = mime_content_type($file['tmp_name']);
            if (isset($allowed[$mime]) && $file['size'] <= 3*1024*1024) {
                $fn     = 'av_' . $uid . '.' . $allowed[$mime];
                $binary = file_get_contents($file['tmp_name']);
                $code   = sb_upload('avatars', $fn, $binary, $mime);
                if ($code >= 200 && $code < 300) {
                    sb_patch('/rest/v1/profiles?id=eq.' . urlencode($uid), ['avatar_url' => sb_public_url('avatars', $fn)]);
                    header('Location: /features/profile/index.php?status=ok&message=' . urlencode('Foto atualizada!'));
                    exit;
                }
            }
        }
        header('Location: /features/profile/index.php?status=error&message=' . urlencode('Erro ao enviar foto.'));
        exit;
    }
}
require ROOT . '/config/layout_top.php';
?>
<style>
.profile-wrap{max-width:600px;margin:0 auto;padding-bottom:32px}
.profile-header{text-align:center;padding:28px 20px 20px;border-bottom:1px solid #141414}
.profile-av-wrap{position:relative;display:inline-block;margin-bottom:14px}
.profile-av{width:90px;height:90px;border-radius:50%;overflow:hidden;background:#1a1a1a;display:flex;align-items:center;justify-content:center;font-size:2.2rem;color:#444;border:3px solid #222;margin:0 auto}
.profile-av img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.profile-av-btn{position:absolute;bottom:2px;right:2px;width:26px;height:26px;border-radius:50%;background:#7B2EFF;border:2px solid #0A0A0A;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:.75rem;color:#fff}
.profile-cl{font-size:1.4rem;font-weight:800;color:#C9A84C;letter-spacing:.06em;margin-bottom:4px}
.profile-sub{font-size:.82rem;color:#555;margin-bottom:4px}
.profile-bio{font-size:.875rem;color:#aaa;line-height:1.5;max-width:300px;margin:8px auto 0}
.profile-stats{display:flex;justify-content:center;gap:32px;padding:16px 20px;border-bottom:1px solid #141414}
.stat{text-align:center}
.stat-num{font-size:1.2rem;font-weight:700;color:#fff}
.stat-lbl{font-size:.7rem;color:#555;margin-top:2px}
.section-title{font-size:.72rem;font-weight:700;color:#555;letter-spacing:.08em;text-transform:uppercase;padding:16px 20px 10px}
.posts-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px}
.post-thumb{aspect-ratio:1;overflow:hidden;background:#111;position:relative}
.post-thumb img{width:100%;height:100%;object-fit:cover;display:block;transition:opacity .2s}
.post-thumb:hover img{opacity:.8}
.post-thumb-del{position:absolute;top:4px;right:4px;background:rgba(0,0,0,.7);border:none;color:#fff;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:.7rem;display:flex;align-items:center;justify-content:center}
.edit-form{padding:20px;background:#111;margin:16px 20px;border-radius:14px;border:1px solid #1e1e1e}
.form-field{margin-bottom:14px}
.form-field label{display:block;font-size:.7rem;font-weight:600;color:#555;letter-spacing:.06em;text-transform:uppercase;margin-bottom:5px}
.form-field input,.form-field textarea,.form-field select{width:100%;background:#1a1a1a;border:1px solid #2a2a2a;border-radius:8px;color:#fff;padding:10px 12px;font-size:.875rem;outline:none;font-family:inherit;transition:border-color .15s}
.form-field input:focus,.form-field textarea:focus,.form-field select:focus{border-color:#7B2EFF}
.form-field select option{background:#1a1a1a}
.form-field textarea{resize:vertical;min-height:80px}
</style>
<div class="profile-wrap">
  <?php if ($status !== ''): ?>
    <div class="alert <?= $status ?>"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div>
  <?php endif; ?>
  <div class="profile-header">
    <form method="POST" enctype="multipart/form-data" id="avForm">
      <input type="hidden" name="action" value="upload_avatar">
      <input type="file" id="avFile" name="avatar" accept="image/jpeg,image/png,image/webp" style="display:none" onchange="document.getElementById('avForm').submit()">
      <div class="profile-av-wrap">
        <div class="profile-av"><?php if ($avatar !== ''): ?><img src="<?= htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8') ?>" alt=""><?php else: ?>👤<?php endif; ?></div>
        <div class="profile-av-btn" onclick="document.getElementById('avFile').click()">📷</div>
      </div>
    </form>
    <div class="profile-cl"><?= htmlspecialchars($clLabel, ENT_QUOTES, 'UTF-8') ?></div>
    <div class="profile-sub">
      <?= htmlspecialchars($profile['tipo'] ?? '', ENT_QUOTES, 'UTF-8') ?>
      <?php if (!empty($profile['cidade'])): ?> · <?= htmlspecialchars($profile['cidade'], ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
      <?php if (!empty($profile['age'])): ?> · <?= (int)$profile['age'] ?> anos<?php if (!empty($profile['partner_age']) && ($profile['tipo'] ?? '') === 'Casal'): ?>/<?= (int)$profile['partner_age'] ?><?php endif; ?><?php endif; ?>
    </div>
    <?php if (!empty($profile['bio'])): ?><div class="profile-bio"><?= htmlspecialchars($profile['bio'], ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
  </div>
  <div class="profile-stats">
    <div class="stat"><div class="stat-num"><?= count($posts) ?></div><div class="stat-lbl">Posts</div></div>
  </div>
  <div class="section-title">Editar perfil</div>
  <form class="edit-form" method="POST">
    <input type="hidden" name="action" value="update_profile">
    <div class="form-field"><label>Bio</label><textarea name="bio" maxlength="500" rows="3"><?= htmlspecialchars($profile['bio'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea></div>
    <div class="form-field"><label>Tipo</label>
      <select name="tipo" id="tipoSelect">
        <?php foreach (['Homem','Mulher','Casal'] as $t): ?><option value="<?= $t ?>" <?= ($profile['tipo'] ?? '') === $t ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?>
      </select></div>
    <div class="form-field"><label>Cidade</label><input type="text" name="cidade" value="<?= htmlspecialchars($profile['cidade'] ?? '', ENT_QUOTES, 'UTF-8') ?>"></div>
    <div class="form-field"><label>Idade</label><input type="number" name="age" min="18" max="99" value="<?= (int)($profile['age'] ?? 0) ?: '' ?>"></div>
    <div class="form-field" id="partnerAgeField" style="display:<?= ($profile['tipo'] ?? '') === 'Casal' ? 'block' : 'none' ?>">
      <label>Idade parceiro(a)</label><input type="number" name="partner_age" min="18" max="99" value="<?= (int)($profile['partner_age'] ?? 0) ?: '' ?>"></div>
    <button class="btn-primary" type="submit" style="width:100%;justify-content:center;margin-top:6px">Salvar</button>
  </form>
  <?php if (!empty($posts)): ?>
    <div class="section-title">Minhas publicações</div>
    <div class="posts-grid">
      <?php foreach ($posts as $p):
        $pId = (string)($p['id'] ?? ''); $pImg = trim((string)($p['image_url'] ?? ''));
        if ($pImg === '') continue;
      ?>
      <div class="post-thumb"><img src="<?= htmlspecialchars($pImg, ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy">
        <form action="/features/feed/delete_post.php" method="POST" onsubmit="return confirm('Excluir?')">
          <input type="hidden" name="post_id" value="<?= htmlspecialchars($pId, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="return_to" value="/features/profile/index.php">
          <button class="post-thumb-del" type="submit">✕</button>
        </form>
      </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<script>
document.getElementById('tipoSelect').addEventListener('change',function(){
  document.getElementById('partnerAgeField').style.display=this.value==='Casal'?'block':'none';
});
</script>
<?php require ROOT . '/config/layout_bottom.php'; ?>

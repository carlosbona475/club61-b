<?php
require_once __DIR__ . '/../../auth_guard.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: /features/feed/index.php'); exit; }

$uid    = (string)$_SESSION['user_id'];
$postId = (int)($_POST['post_id'] ?? 0);
$content = trim($_POST['content'] ?? '');
$return  = trim($_POST['return_to'] ?? '/features/feed/index.php');

if ($postId && $content !== '' && mb_strlen($content, 'UTF-8') <= 500) {
    sb_post('/rest/v1/post_comments', [
        'post_id'      => $postId,
        'user_id'      => $uid,
        'comment_text' => $content,
    ]);
}
header('Location: '.$return); exit;

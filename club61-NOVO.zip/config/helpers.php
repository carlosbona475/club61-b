<?php
require_once __DIR__ . '/config.php';

// ── Sessão ────────────────────────────────────────────────────────────────────
function c61_session(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

function c61_logged_in(): bool {
    c61_session();
    return !empty($_SESSION['access_token']) && !empty($_SESSION['user_id']);
}

function c61_uid(): string {
    return (string)($_SESSION['user_id'] ?? '');
}

function c61_token(): string {
    return (string)($_SESSION['access_token'] ?? '');
}

function c61_require_login(): void {
    if (!c61_logged_in()) {
        header('Location: /features/auth/login.php');
        exit;
    }
}

// ── cURL Supabase ─────────────────────────────────────────────────────────────
function sb_get(string $path, bool $service = true): array {
    $key = $service ? SUPABASE_SERVICE_KEY : SUPABASE_ANON_KEY;
    $ch  = curl_init(SUPABASE_URL . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            'apikey: '         . $key,
            'Authorization: Bearer ' . $key,
            'Accept: application/json',
        ],
    ]);
    $raw  = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $code < 200 || $code >= 300) return [];
    $dec = json_decode($raw, true);
    return is_array($dec) ? $dec : [];
}

function sb_post(string $path, array $data, bool $service = true): int {
    $key = $service ? SUPABASE_SERVICE_KEY : SUPABASE_ANON_KEY;
    $ch  = curl_init(SUPABASE_URL . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_POSTFIELDS     => json_encode($data, JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER     => [
            'apikey: '         . $key,
            'Authorization: Bearer ' . $key,
            'Content-Type: application/json',
            'Prefer: return=minimal',
        ],
    ]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code;
}

function sb_patch(string $path, array $data, bool $service = true): int {
    $key = $service ? SUPABASE_SERVICE_KEY : SUPABASE_ANON_KEY;
    $ch  = curl_init(SUPABASE_URL . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'PATCH',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_POSTFIELDS     => json_encode($data, JSON_UNESCAPED_SLASHES),
        CURLOPT_HTTPHEADER     => [
            'apikey: '         . $key,
            'Authorization: Bearer ' . $key,
            'Content-Type: application/json',
            'Prefer: return=minimal',
        ],
    ]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code;
}

function sb_delete(string $path, bool $service = true): int {
    $key = $service ? SUPABASE_SERVICE_KEY : SUPABASE_ANON_KEY;
    $ch  = curl_init(SUPABASE_URL . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'DELETE',
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER     => [
            'apikey: '         . $key,
            'Authorization: Bearer ' . $key,
            'Prefer: return=minimal',
        ],
    ]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code;
}

function sb_upload(string $bucket, string $filename, string $binary, string $mime): int {
    $ch = curl_init(SUPABASE_URL . '/storage/v1/object/' . $bucket . '/' . $filename);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_POSTFIELDS     => $binary,
        CURLOPT_HTTPHEADER     => [
            'apikey: '         . SUPABASE_SERVICE_KEY,
            'Authorization: Bearer ' . SUPABASE_SERVICE_KEY,
            'Content-Type: '   . $mime,
            'x-upsert: true',
        ],
    ]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code;
}

function sb_public_url(string $bucket, string $filename): string {
    return SUPABASE_URL . '/storage/v1/object/public/' . $bucket . '/' . $filename;
}

// ── Perfil ────────────────────────────────────────────────────────────────────
function c61_get_profile(string $uid): array {
    $rows = sb_get('/rest/v1/profiles?id=eq.' . urlencode($uid) . '&select=id,username,display_id,avatar_url,bio,age,partner_age,tipo,cidade,role,status,last_seen');
    return $rows[0] ?? [];
}

function c61_is_admin(): bool {
    c61_session();
    $uid = c61_uid();
    if ($uid === '') return false;
    $profile = c61_get_profile($uid);
    return ($profile['role'] ?? '') === 'admin' && ($profile['status'] ?? '') !== 'banned';
}

function c61_require_admin(): void {
    c61_require_login();
    if (!c61_is_admin()) {
        header('Location: /features/feed/index.php?status=error&message=' . urlencode('Acesso negado.'));
        exit;
    }
}

// ── Labels ────────────────────────────────────────────────────────────────────
function c61_cl_label(array $profile, string $fallback = 'Membro'): string {
    $d = trim((string)($profile['display_id'] ?? ''));
    $u = trim((string)($profile['username']   ?? ''));
    if ($d !== '') {
        if (preg_match('/^CL\s*0*(\d+)$/i', $d, $m))
            return 'CL' . str_pad((string)(int)$m[1], 2, '0', STR_PAD_LEFT);
        $dig = preg_replace('/\D/', '', $d);
        if ($dig !== '') return 'CL' . str_pad($dig, 2, '0', STR_PAD_LEFT);
    }
    return $u !== '' ? '@' . $u : $fallback;
}

function c61_time_ago(string $iso): string {
    if ($iso === '') return '';
    $diff = time() - strtotime($iso);
    if ($diff < 60)    return 'agora';
    if ($diff < 3600)  return floor($diff/60) . 'min';
    if ($diff < 86400) return floor($diff/3600) . 'h';
    return floor($diff/86400) . 'd';
}

function c61_is_online(?string $lastSeen): bool {
    if (!$lastSeen) return false;
    return (time() - strtotime($lastSeen)) < 120;
}

function c61_touch_last_seen(): void {
    $uid = c61_uid();
    if ($uid === '') return;
    sb_patch('/rest/v1/profiles?id=eq.' . urlencode($uid),
        ['last_seen' => gmdate('Y-m-d\TH:i:s\Z')]);
}

// ── Membros online (sidebar) ──────────────────────────────────────────────────
function c61_online_members(): array {
    $since = gmdate('Y-m-d\TH:i:s\Z', time() - 120);
    return sb_get('/rest/v1/profiles?select=id,display_id,username,avatar_url,cidade,last_seen&last_seen=gte.' . rawurlencode($since) . '&order=last_seen.desc&limit=30');
}

<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();

$uid    = c61_uid();
$viewId = trim($_GET['user_id'] ?? '');
if ($viewId === '') { header('Location: /features/feed/index.php'); exit; }

$nowIso = gmdate('Y-m-d\TH:i:s\Z');
$stories = sb_get('/rest/v1/stories?user_id=eq.' . urlencode($viewId) . '&expires_at=gt.' . rawurlencode($nowIso) . '&select=id,image_url,expires_at,created_at&order=created_at.desc&limit=1');
$story   = $stories[0] ?? [];
$imgUrl  = trim((string)($story['image_url'] ?? ''));

$profile = c61_get_profile($viewId);
$label   = c61_cl_label($profile);
$avatar  = trim((string)($profile['avatar_url'] ?? ''));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Story — Club61</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;background:#000;color:#fff;font-family:'Segoe UI',system-ui,sans-serif;overflow:hidden}
.story-root{position:fixed;inset:0;display:flex;flex-direction:column;background:#000}
.progress{flex-shrink:0;padding:10px 12px 0}
.progress-track{height:3px;background:rgba(255,255,255,.2);border-radius:2px;overflow:hidden}
.progress-fill{height:100%;width:100%;background:#fff;animation:drain 5s linear forwards}
@keyframes drain{from{width:100%}to{width:0%}}
.story-top{display:flex;align-items:center;justify-content:space-between;padding:8px 12px 12px}
.story-user{display:flex;align-items:center;gap:10px}
.story-av{width:36px;height:36px;border-radius:50%;overflow:hidden;background:#1a1a1a;
           display:flex;align-items:center;justify-content:center;font-size:1.1rem;color:#444;flex-shrink:0}
.story-av img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.story-label{font-size:.85rem;font-weight:600;color:#fff}
.close-btn{background:rgba(255,255,255,.15);border:none;border-radius:50%;width:38px;height:38px;
           color:#fff;font-size:1.2rem;cursor:pointer;display:flex;align-items:center;justify-content:center}
.story-img{flex:1;display:flex;align-items:center;justify-content:center;padding:0 8px 24px}
.story-img img{max-width:100%;max-height:100%;object-fit:contain}
.story-empty{flex:1;display:flex;align-items:center;justify-content:center;color:#555;font-size:.9rem}
</style>
</head>
<body>
<div class="story-root">
  <div class="progress"><div class="progress-track"><div class="progress-fill"></div></div></div>
  <div class="story-top">
    <div class="story-user">
      <div class="story-av"><?php if ($avatar !== ''): ?><img src="<?= htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8') ?>" alt=""><?php else: ?>👤<?php endif; ?></div>
      <span class="story-label"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></span>
    </div>
    <button class="close-btn" onclick="window.location='/features/feed/index.php'">×</button>
  </div>
  <?php if ($imgUrl !== ''): ?>
    <div class="story-img"><img src="<?= htmlspecialchars($imgUrl, ENT_QUOTES, 'UTF-8') ?>" alt="Story"></div>
  <?php else: ?>
    <div class="story-empty">Story não encontrado ou expirado.</div>
  <?php endif; ?>
</div>
<script>setTimeout(function(){ window.location='/features/feed/index.php'; }, 5000);</script>
</body>
</html>

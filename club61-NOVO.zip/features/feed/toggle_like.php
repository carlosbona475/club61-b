<?php
require_once __DIR__ . '/../../auth_guard.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: /features/feed/index.php'); exit; }

$uid    = (string)$_SESSION['user_id'];
$postId = (int)($_POST['post_id'] ?? 0);
$return = trim($_POST['return_to'] ?? '/features/feed/index.php');
if (!$postId) { header('Location: '.$return); exit; }

$existing = sb_get('/rest/v1/post_likes?post_id=eq.'.$postId.'&user_id=eq.'.urlencode($uid).'&select=id');
if ($existing) {
    sb_delete('/rest/v1/post_likes?post_id=eq.'.$postId.'&user_id=eq.'.urlencode($uid));
} else {
    sb_post('/rest/v1/post_likes', ['post_id' => $postId, 'user_id' => $uid]);
}
header('Location: '.$return); exit;

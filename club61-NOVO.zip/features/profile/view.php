<?php
define('ROOT', __DIR__ . '/../..');
require_once ROOT . '/config/helpers.php';
c61_require_login();
$uid    = c61_uid();
$viewId = trim($_GET['id'] ?? $_GET['user_id'] ?? '');
if ($viewId === '') $viewId = $uid;
$pageTitle  = 'Perfil';
$activePage = 'profile';
$profile  = c61_get_profile($viewId);
$clLabel  = c61_cl_label($profile);
$avatar   = trim((string)($profile['avatar_url'] ?? ''));
$isOnline = c61_is_online($profile['last_seen'] ?? null);
$posts    = sb_get('/rest/v1/posts?user_id=eq.' . urlencode($viewId) . '&select=id,image_url,caption,created_at&order=created_at.desc&limit=30');
$isMe     = $viewId === $uid;
require ROOT . '/config/layout_top.php';
?>
<style>
.view-wrap{max-width:600px;margin:0 auto;padding-bottom:32px}
.view-header{text-align:center;padding:28px 20px 20px;border-bottom:1px solid #141414}
.view-av{width:90px;height:90px;border-radius:50%;overflow:hidden;background:#1a1a1a;display:flex;align-items:center;justify-content:center;font-size:2.2rem;color:#444;border:3px solid #222;margin:0 auto 14px}
.view-av.online{border-color:#22c55e}
.view-av img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.view-cl{font-size:1.4rem;font-weight:800;color:#C9A84C;letter-spacing:.06em;margin-bottom:4px}
.view-sub{font-size:.82rem;color:#555;margin-bottom:4px}
.view-bio{font-size:.875rem;color:#aaa;line-height:1.5;max-width:300px;margin:8px auto 0}
.view-actions{display:flex;gap:10px;justify-content:center;margin-top:16px}
.posts-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:2px}
.post-thumb{aspect-ratio:1;overflow:hidden;background:#111}
.post-thumb img{width:100%;height:100%;object-fit:cover;display:block}
.stats-row{display:flex;justify-content:center;gap:32px;padding:16px;border-bottom:1px solid #141414}
.stat{text-align:center}
.stat-num{font-size:1.2rem;font-weight:700;color:#fff}
.stat-lbl{font-size:.7rem;color:#555;margin-top:2px}
.section-title{font-size:.72rem;font-weight:700;color:#555;letter-spacing:.08em;text-transform:uppercase;padding:16px 20px 10px}
</style>
<div class="view-wrap">
  <div class="view-header">
    <div class="view-av <?= $isOnline ? 'online' : '' ?>"><?php if ($avatar !== ''): ?><img src="<?= htmlspecialchars($avatar, ENT_QUOTES, 'UTF-8') ?>" alt=""><?php else: ?>👤<?php endif; ?></div>
    <?php if ($isOnline): ?><div style="display:inline-block;background:#22c55e;color:#fff;font-size:.65rem;font-weight:700;border-radius:10px;padding:2px 8px;margin-bottom:6px">🟢 Online agora</div><?php endif; ?>
    <div class="view-cl"><?= htmlspecialchars($clLabel, ENT_QUOTES, 'UTF-8') ?></div>
    <div class="view-sub">
      <?= htmlspecialchars($profile['tipo'] ?? '', ENT_QUOTES, 'UTF-8') ?>
      <?php if (!empty($profile['cidade'])): ?> · <?= htmlspecialchars($profile['cidade'], ENT_QUOTES, 'UTF-8') ?><?php endif; ?>
      <?php if (!empty($profile['age'])): ?> · <?= (int)$profile['age'] ?> anos<?php if (!empty($profile['partner_age']) && ($profile['tipo'] ?? '') === 'Casal'): ?>/<?= (int)$profile['partner_age'] ?><?php endif; ?><?php endif; ?>
    </div>
    <?php if (!empty($profile['bio'])): ?><div class="view-bio"><?= htmlspecialchars($profile['bio'], ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <div class="view-actions">
      <?php if (!$isMe): ?>
        <a class="btn-primary" href="/features/chat/dm.php?with=<?= urlencode($viewId) ?>">💬 Mensagem</a>
      <?php else: ?>
        <a class="btn-ghost" href="/features/profile/index.php">✏️ Editar perfil</a>
      <?php endif; ?>
    </div>
  </div>
  <div class="stats-row">
    <div class="stat"><div class="stat-num"><?= count($posts) ?></div><div class="stat-lbl">Posts</div></div>
  </div>
  <?php if (!empty($posts)): ?>
    <div class="section-title">Publicações</div>
    <div class="posts-grid">
      <?php foreach ($posts as $p): $pImg = trim((string)($p['image_url'] ?? '')); if ($pImg === '') continue; ?>
      <div class="post-thumb"><img src="<?= htmlspecialchars($pImg, ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy"></div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php require ROOT . '/config/layout_bottom.php'; ?>
